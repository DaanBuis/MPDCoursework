package org.me.gcu.buis_daan_s2025985;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.LinkedList;

public class FragmentOne extends Fragment implements View.OnClickListener {
    static String tempText1 = "";
    static String tempText2 = "";
    static String tempText3 = "";
    static String tempText4 = "";
    static String tempText5 = "";
    private Button backButton;
    private Button nextButton;
    private Button magniSearch;
    private Button depthSearch;
    private Button north;
    private Button east;
    private Button west;
    private Button south;

    private TextView pageNum;
    private Button clearSearch;

    private EditText searchLoc;
    private ToggleButton fr1Button;
    private TextView fr1Loc;
    private TextView fr1Date;
    private TextView fr1Cord;
    private TextView fr1Magni;
    private TextView fr1Depth;

    private ToggleButton sr1Button;
    private TextView sr1Loc;
    private TextView sr1Date;
    private TextView sr1Cord;
    private TextView sr1Magni;
    private TextView sr1Depth;

    private ToggleButton sr2Button;
    private TextView sr2Loc;
    private TextView sr2Date;
    private TextView sr2Cord;
    private TextView sr2Magni;
    private TextView sr2Depth;

    private ToggleButton sr3Button;
    private TextView sr3Loc;
    private TextView sr3Date;
    private TextView sr3Cord;
    private TextView sr3Magni;
    private TextView sr3Depth;
    private ToggleButton sr4Button;
    private TextView sr4Loc;
    private TextView sr4Date;
    private TextView sr4Cord;
    private TextView sr4Magni;
    private TextView sr4Depth;
    private ToggleButton sr5Button;
    private TextView sr5Loc;
    private TextView sr5Date;
    private TextView sr5Cord;
    private TextView sr5Magni;
    private TextView sr5Depth;

    private ToggleButton fr2Button;
    private TextView fr2Loc;
    private TextView fr2Date;
    private TextView fr2Cord;
    private TextView fr2Magni;
    private TextView fr2Depth;

    private ToggleButton fr3Button;
    private TextView fr3Loc;
    private TextView fr3Date;
    private TextView fr3Cord;
    private TextView fr3Magni;
    private TextView fr3Depth;

    private ToggleButton fr4Button;
    private TextView fr4Loc;
    private TextView fr4Date;
    private TextView fr4Cord;
    private TextView fr4Magni;
    private TextView fr4Depth;
    private ToggleButton fr5Button;
    private TextView fr5Loc;
    private TextView fr5Date;
    private TextView fr5Cord;
    private TextView fr5Magni;
    private TextView fr5Depth;

    private ToggleButton fr6Button;
    private TextView fr6Loc;
    private TextView fr6Date;
    private TextView fr6Cord;
    private TextView fr6Magni;
    private TextView fr6Depth;

    private ToggleButton fr7Button;
    private TextView fr7Loc;
    private TextView fr7Date;
    private TextView fr7Cord;
    private TextView fr7Magni;
    private TextView fr7Depth;

    private ToggleButton fr8Button;
    private TextView fr8Loc;
    private TextView fr8Date;
    private TextView fr8Cord;
    private TextView fr8Magni;
    private TextView fr8Depth;

    private ToggleButton fr9Button;
    private TextView fr9Loc;
    private TextView fr9Date;
    private TextView fr9Cord;
    private TextView fr9Magni;
    private TextView fr9Depth;

    private ToggleButton fr10Button;
    private TextView fr10Loc;
    private TextView fr10Date;
    private TextView fr10Cord;
    private TextView fr10Magni;
    private TextView fr10Depth;
    private ArrayList<String> alist = null;
    private String data;
    private EditText searchDate;
    private Button dateButton;

    private static double ggowLat = 55.860;
    private static double ggowLong = -4.251;

    private static int page = 0;

    public FragmentOne() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        View v = inflater.inflate(R.layout.fragment_fragment_one, container, false);
        page = 0;
        backButton = (Button) v.findViewById(R.id.backButton);
        nextButton = (Button) v.findViewById(R.id.nextButton);
        pageNum = (TextView) v.findViewById(R.id.pageNum);
        pageNum.setText("1-10");

        searchDate = (EditText) v.findViewById(R.id.searchDate);
        dateButton = (Button) v.findViewById(R.id.dateButton);
        clearSearch = (Button) v.findViewById(R.id.clearButton);
        searchLoc = (EditText) v.findViewById(R.id.searchLoc);
        magniSearch = (Button) v.findViewById(R.id.magniButton);
        depthSearch = (Button) v.findViewById(R.id.depthButton);
        north = (Button) v.findViewById(R.id.northButton);
        south = (Button) v.findViewById(R.id.southButton);
        west = (Button) v.findViewById(R.id.westButton);
        east = (Button) v.findViewById(R.id.eastButton);

        magniSearch.setOnClickListener(this);
        depthSearch.setOnClickListener(this);
        north.setOnClickListener(this);
        west.setOnClickListener(this);
        east.setOnClickListener(this);
        south.setOnClickListener(this);
        dateButton.setOnClickListener(this);
        clearSearch.setOnClickListener(this);
        searchLoc.setOnClickListener(this);





        data = getArguments().getString("data");

        sr1Button = (ToggleButton) v.findViewById(R.id.sr1_button);
        sr1Loc = (TextView) v.findViewById(R.id.sr1_location);
        sr1Date = (TextView) v.findViewById(R.id.sr1_date);
        sr1Cord = (TextView) v.findViewById(R.id.sr1_cord);
        sr1Magni = (TextView) v.findViewById(R.id.sr1_magni);
        sr1Depth = (TextView) v.findViewById(R.id.sr1_depth);

        sr2Button = (ToggleButton) v.findViewById(R.id.sr2_button);
        sr2Loc = (TextView) v.findViewById(R.id.sr2_location);
        sr2Date = (TextView) v.findViewById(R.id.sr2_date);
        sr2Cord = (TextView) v.findViewById(R.id.sr2_cord);
        sr2Magni = (TextView) v.findViewById(R.id.sr2_magni);
        sr2Depth = (TextView) v.findViewById(R.id.sr2_depth);

        sr3Button = (ToggleButton) v.findViewById(R.id.sr3_button);
        sr3Loc = (TextView) v.findViewById(R.id.sr3_location);
        sr3Date = (TextView) v.findViewById(R.id.sr3_date);
        sr3Cord = (TextView) v.findViewById(R.id.sr3_cord);
        sr3Magni = (TextView) v.findViewById(R.id.sr3_magni);
        sr3Depth = (TextView) v.findViewById(R.id.sr3_depth);

        sr4Button = (ToggleButton) v.findViewById(R.id.sr4_button);
        sr4Loc = (TextView) v.findViewById(R.id.sr4_location);
        sr4Date = (TextView) v.findViewById(R.id.sr4_date);
        sr4Cord = (TextView) v.findViewById(R.id.sr4_cord);
        sr4Magni = (TextView) v.findViewById(R.id.sr4_magni);
        sr4Depth = (TextView) v.findViewById(R.id.sr4_depth);

        sr5Button = (ToggleButton) v.findViewById(R.id.sr5_button);
        sr5Loc = (TextView) v.findViewById(R.id.sr5_location);
        sr5Date = (TextView) v.findViewById(R.id.sr5_date);
        sr5Cord = (TextView) v.findViewById(R.id.sr5_cord);
        sr5Magni = (TextView) v.findViewById(R.id.sr5_magni);
        sr5Depth = (TextView) v.findViewById(R.id.sr5_depth);

        fr1Button = (ToggleButton) v.findViewById(R.id.fr1_button);
        fr1Loc = (TextView) v.findViewById(R.id.fr1_location);
        fr1Date = (TextView) v.findViewById(R.id.fr1_date);
        fr1Cord = (TextView) v.findViewById(R.id.fr1_cord);
        fr1Magni = (TextView) v.findViewById(R.id.fr1_magni);
        fr1Depth = (TextView) v.findViewById(R.id.fr1_depth);

        fr2Button = (ToggleButton) v.findViewById(R.id.fr2_button);
        fr2Loc = (TextView) v.findViewById(R.id.fr2_location);
        fr2Date = (TextView) v.findViewById(R.id.fr2_date);
        fr2Cord = (TextView) v.findViewById(R.id.fr2_cord);
        fr2Magni = (TextView) v.findViewById(R.id.fr2_magni);
        fr2Depth = (TextView) v.findViewById(R.id.fr2_depth);

        fr3Button = (ToggleButton) v.findViewById(R.id.fr3_button);
        fr3Loc = (TextView) v.findViewById(R.id.fr3_location);
        fr3Date = (TextView) v.findViewById(R.id.fr3_date);
        fr3Cord = (TextView) v.findViewById(R.id.fr3_cord);
        fr3Magni = (TextView) v.findViewById(R.id.fr3_magni);
        fr3Depth = (TextView) v.findViewById(R.id.fr3_depth);

        fr4Button = (ToggleButton) v.findViewById(R.id.fr4_button);
        fr4Loc = (TextView) v.findViewById(R.id.fr4_location);
        fr4Date = (TextView) v.findViewById(R.id.fr4_date);
        fr4Cord = (TextView) v.findViewById(R.id.fr4_cord);
        fr4Magni = (TextView) v.findViewById(R.id.fr4_magni);
        fr4Depth = (TextView) v.findViewById(R.id.fr4_depth);

        fr5Button = (ToggleButton) v.findViewById(R.id.fr5_button);
        fr5Loc = (TextView) v.findViewById(R.id.fr5_location);
        fr5Date = (TextView) v.findViewById(R.id.fr5_date);
        fr5Cord = (TextView) v.findViewById(R.id.fr5_cord);
        fr5Magni = (TextView) v.findViewById(R.id.fr5_magni);
        fr5Depth = (TextView) v.findViewById(R.id.fr5_depth);

        fr6Button = (ToggleButton) v.findViewById(R.id.fr6_button);
        fr6Loc = (TextView) v.findViewById(R.id.fr6_location);
        fr6Date = (TextView) v.findViewById(R.id.fr6_date);
        fr6Cord = (TextView) v.findViewById(R.id.fr6_cord);
        fr6Magni = (TextView) v.findViewById(R.id.fr6_magni);
        fr6Depth = (TextView) v.findViewById(R.id.fr6_depth);

        fr7Button = (ToggleButton) v.findViewById(R.id.fr7_button);
        fr7Loc = (TextView) v.findViewById(R.id.fr7_location);
        fr7Date = (TextView) v.findViewById(R.id.fr7_date);
        fr7Cord = (TextView) v.findViewById(R.id.fr7_cord);
        fr7Magni = (TextView) v.findViewById(R.id.fr7_magni);
        fr7Depth = (TextView) v.findViewById(R.id.fr7_depth);

        fr8Button = (ToggleButton) v.findViewById(R.id.fr8_button);
        fr8Loc = (TextView) v.findViewById(R.id.fr8_location);
        fr8Date = (TextView) v.findViewById(R.id.fr8_date);
        fr8Cord = (TextView) v.findViewById(R.id.fr8_cord);
        fr8Magni = (TextView) v.findViewById(R.id.fr8_magni);
        fr8Depth = (TextView) v.findViewById(R.id.fr8_depth);

        fr9Button = (ToggleButton) v.findViewById(R.id.fr9_button);
        fr9Loc = (TextView) v.findViewById(R.id.fr9_location);
        fr9Date = (TextView) v.findViewById(R.id.fr9_date);
        fr9Cord = (TextView) v.findViewById(R.id.fr9_cord);
        fr9Magni = (TextView) v.findViewById(R.id.fr9_magni);
        fr9Depth = (TextView) v.findViewById(R.id.fr9_depth);

        fr10Button = (ToggleButton) v.findViewById(R.id.fr10_button);
        fr10Loc = (TextView) v.findViewById(R.id.fr10_location);
        fr10Date = (TextView) v.findViewById(R.id.fr10_date);
        fr10Cord = (TextView) v.findViewById(R.id.fr10_cord);
        fr10Magni = (TextView) v.findViewById(R.id.fr10_magni);
        fr10Depth = (TextView) v.findViewById(R.id.fr10_depth);

        fr1Button.setOnClickListener(this);
        fr2Button.setOnClickListener(this);
        fr3Button.setOnClickListener(this);
        fr4Button.setOnClickListener(this);
        fr5Button.setOnClickListener(this);
        fr6Button.setOnClickListener(this);
        fr7Button.setOnClickListener(this);
        fr8Button.setOnClickListener(this);
        fr9Button.setOnClickListener(this);
        fr10Button.setOnClickListener(this);

        sr1Button.setOnClickListener(this);
        sr2Button.setOnClickListener(this);
        sr3Button.setOnClickListener(this);
        sr4Button.setOnClickListener(this);
        sr5Button.setOnClickListener(this);

        backButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);

        try {
            Thread.sleep(500);
            alist = convertToList(data);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println(alist.get(1));
        alist.get(0);
        fr1Button.setText("Earthquake at: " + alist.get(1).substring(11, alist.get(1).length() - 91));
        fr2Button.setText("Earthquake at: " + alist.get(2).substring(11, alist.get(2).length() - 91));
        fr3Button.setText("Earthquake at: " + alist.get(3).substring(11, alist.get(3).length() - 91));
        fr4Button.setText("Earthquake at: " + alist.get(4).substring(11, alist.get(3).length() - 91));
        fr5Button.setText("Earthquake at: " + alist.get(5).substring(11, alist.get(3).length() - 91));
        fr6Button.setText("Earthquake at: " + alist.get(6).substring(11, alist.get(3).length() - 91));
        fr7Button.setText("Earthquake at: " + alist.get(7).substring(11, alist.get(3).length() - 91));
        fr8Button.setText("Earthquake at: " + alist.get(8).substring(11, alist.get(3).length() - 91));
        fr9Button.setText("Earthquake at: " + alist.get(9).substring(11, alist.get(3).length() - 91));
        fr10Button.setText("Earthquake at: " + alist.get(10).substring(11, alist.get(3).length() - 91));
        return v;

    }

    public ArrayList<String> convertToList(String param) {
        String msg = param;
        ArrayList<String> alist = new ArrayList<>(Arrays.asList(msg.split("WidgetClass")));


        return alist;
    }

    public String getLoc(int pagenum, int entryNum) {
        String loc = "";
        int value = 0;

        switch (pagenum) {
            case 0:
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 1:
                value += 10;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 2:
                value += 20;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 3:
                value += 30;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 4:
                value += 40;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 5:
                value += 50;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 6:
                value += 60;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 7:
                value += 70;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 8:
                value += 80;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 9:
                value += 90;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 10:
                value += 100;
                loc = alist.get(entryNum + value).substring(11, alist.get(entryNum + value).length() - 91);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;


        }

        return loc;
    }

    public String getDate(int pagenum, int entryNum) {
        String loc = "";
        int value = 0;

        switch (pagenum) {
            case 0:
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 1:
                value += 10;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 2:
                value += 20;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 3:
                value += 30;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 4:
                value += 40;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 5:
                value += 50;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 6:
                value += 60;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 7:
                value += 70;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 8:
                value += 80;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 9:
                value += 90;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 10:
                value += 100;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;


        }

        return loc;
    }

    public String getMagni(int pagenum, int entryNum) {
        String loc = "";
        int value = 0;

        switch (pagenum) {
            case 0:
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 1:
                value += 10;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 2:
                value += 20;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 3:
                value += 30;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 4:
                value += 40;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 5:
                value += 50;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 6:
                value += 60;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 7:
                value += 70;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 8:
                value += 80;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 9:
                value += 90;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;
            case 10:
                value += 100;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 7, alist.get(entryNum + value).length() - 4);
                break;


        }
        loc = loc.replaceAll("'","");
        loc = loc.replace("","");

        return loc;
    }

    public String getDepth(int pagenum, int entryNum) {
        String loc = "";
        int value = 0;
        switch (pagenum) {
            case 0:
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 81, alist.get(entryNum + value).length() - 78);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 1:
                value += 10;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 2:
                value += 20;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 3:
                value += 30;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 4:
                value += 40;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 5:
                value += 50;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 6:
                value += 60;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 7:
                value += 70;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 8:
                value += 80;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 9:
                value += 90;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
            case 10:
                value += 100;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 5, alist.get(entryNum + value).length() - 4);
                loc = loc.replaceAll("'","");
                loc = loc.replace("","");
                break;
        }
        loc = loc.replaceAll("'","");
        loc = loc.replace("","");


        return loc;
    }

    public String getLong(int pagenum, int entryNum) {
        String loc = "";
        int value = 0;

        switch (pagenum) {
            case 0:
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 1:
                value += 10;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 2:
                value += 20;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 3:
                value += 30;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 4:
                value += 40;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 5:
                value += 50;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 6:
                value += 60;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 7:
                value += 70;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 8:
                value += 80;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 9:
                value += 90;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;
            case 10:
                value += 100;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 46, alist.get(entryNum + value).length() - 40);
                break;


        }
        loc = loc.replaceAll("'","");
        loc = loc.replace("","");

        return loc;
    }

    public String getLat(int pagenum, int entryNum) {
        String loc = "";
        int value = 0;

        switch (pagenum) {
            case 0:
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 1:
                value += 10;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 2:
                value += 20;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 3:
                value += 30;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 4:
                value += 40;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 5:
                value += 50;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 6:
                value += 60;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 7:
                value += 70;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 8:
                value += 80;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 9:
                value += 90;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;
            case 10:
                value += 100;
                loc = alist.get(entryNum + value).substring(alist.get(entryNum + value).length() - 27, alist.get(entryNum + value).length() - 21);
                break;


        }
        loc = loc.replaceAll("'","");
        loc = loc.replace("","");

        return loc;
    }

    public int magniColour(String magnitude) {
        int red = Color.RED;
        int green = Color.GREEN;
        int yellow = Color.YELLOW;
        int colour = 0;
        double intMagni = Double.parseDouble(magnitude);
        if (intMagni < 1) {
            colour = green;
        } else if (intMagni >= 1 && intMagni < 2 ) {
            colour = yellow;
        } else if (intMagni > 2) {
            colour = red;
        }

        return colour;
    }

    public ArrayList<String> getSearchDate(String sDate) {
        ArrayList<String> infoList = new ArrayList<>();
        String tempAList = "";

        for (int i = 1; i <= alist.size() - 1; i++) {
            tempAList = alist.get(i).substring(alist.get(i).length() - 70, alist.get(i).length() - 59).toString();
            tempAList = tempAList.replaceAll("'","");

            if (sDate.equals(tempAList)) {
               infoList.add(alist.get(i));
            }


        }



        return infoList;
    }

    public ArrayList<String> getSearchLoc(ArrayList<String> listLoc, String sLoc) {
        ArrayList<String> infoList = listLoc;
        ArrayList<String> returnList = new ArrayList<>();
        String upperCase = sLoc.toUpperCase();

        for (int i = 0; i <= infoList.size() - 1; i++) {
            if (listLoc.get(i).contains(upperCase)) {
                returnList.add(listLoc.get(i));

            }




        }



        return returnList;
    }


    public ArrayList<String> getNorth() {
        String tempLat1 = "";
        String tempLat2 = "";
        Double doLat1 = 0.0;
        Double doLat2 = 0.0;
        Double tempLat = 0.0;
        ArrayList<String> tempResult = new ArrayList<String>(1);


        for (int i = 1; i <= alist.size() - 2; i++) {
            tempLat1 = alist.get(i).substring(alist.get(i).length() - 27, alist.get(i).length() - 21);
            tempLat2 = alist.get(i + 1).substring(alist.get(i + 1).length() - 27, alist.get(i + 1).length() - 21);


            tempLat1 = tempLat1.replaceAll("'", "");
            tempLat2 = tempLat2.replaceAll("'", "");
            doLat1 = Double.parseDouble(tempLat1);
            doLat2 = Double.parseDouble(tempLat2);

            if (doLat1 < ggowLat + 0.1 && doLat1 > ggowLat - 0.1) {
                tempLat = doLat1;
                if (Math.abs(ggowLat - tempLat) > Math.abs(ggowLat - doLat2)) {
                    tempLat = doLat1;
                    tempResult.add("");
                    tempResult.set(0, alist.get(i));
                } else if (Math.abs(ggowLat - tempLat) < Math.abs(ggowLat - doLat2)) {
                    tempLat = doLat2;
                    tempResult.add("");
                    tempResult.set(0, alist.get(i + 1));
                }
            }

        }
        return tempResult;
    }

    public ArrayList<String> getSouth() {
        String tempLat1 = "";
        String tempLat2 = "";
        Double doLat1 = 0.0;
        Double doLat2 = 0.0;
        ArrayList<String> tempResult = new ArrayList<String>(1);


        for (int i = 1; i <= alist.size() - 2; i++) {
            tempLat1 = alist.get(i).substring(alist.get(i).length() - 27, alist.get(i).length() - 21);
            tempLat2 = alist.get(i + 1).substring(alist.get(i + 1).length() - 27, alist.get(i + 1).length() - 21);


            tempLat1 = tempLat1.replaceAll("'","");
            tempLat2 = tempLat2.replaceAll("'","");
            doLat1 = Double.parseDouble(tempLat1);
            doLat2 = Double.parseDouble(tempLat2);

            if (doLat1 < ggowLat && doLat2 < ggowLat && Math.abs(ggowLat - doLat1) < Math.abs(ggowLat - doLat2)) {
                tempResult.add("");
                tempResult.set(0, alist.get(i));
            } else if ( doLat1 < ggowLat && doLat2 < ggowLat && Math.abs(ggowLat - doLat1) > Math.abs(ggowLat - doLat2)) {
                tempResult.add("");
                tempResult.set(0, alist.get(i + 1));
            }
        }
        return tempResult;
    }

    public ArrayList<String> getEast() {
        String tempLong1 = "";
        String tempLong2 = "";
        Double doLong1 = 0.0;
        Double doLong2 = 0.0;
        ArrayList<String> tempResult = new ArrayList<String>(1);


        for (int i = 1; i <= alist.size() - 2; i++) {
            tempLong1 = alist.get(i).substring(alist.get(i).length() - 46, alist.get(i).length() - 40);
            tempLong2 = alist.get(i + 1).substring(alist.get(i + 1).length() - 46, alist.get(i + 1).length() - 40);

            tempLong1 = tempLong1.replaceAll("'","");
            tempLong2 = tempLong2.replaceAll("'","");
            doLong1 = Double.parseDouble(tempLong1);
            doLong2 = Double.parseDouble(tempLong2);

            if (doLong1 > ggowLong && doLong2 > ggowLong  && Math.abs(ggowLong - doLong1) < Math.abs(ggowLong - doLong2)) {
                tempResult.add("");
                tempResult.set(0, alist.get(i));
            } else if (doLong1 > ggowLong && doLong2 > ggowLong  && Math.abs(ggowLong - doLong1) > Math.abs(ggowLong - doLong2)) {
                tempResult.add("");
                tempResult.set(0, alist.get(i + 1));
            }
        }
        return tempResult;
    }


    public void updateLocSearch(ArrayList<String> blist) {

            for (int i = 0; i <= blist.size() - 1; i++) {
                switch (i) {
                    case 0:
                        sr1Button.setVisibility(View.VISIBLE);
                        sr1Button.setText("Earthquake at: " + blist.get(0).substring(11, blist.get(0).length() - 91));
                        sr1Loc.setText("Location: " + blist.get(0).substring(11, blist.get(0).length() - 91));
                        sr1Date.setText("Date: " + blist.get(0).substring(blist.get(0).length() - 70, blist.get(0).length() - 59));
                        sr1Magni.setText("Magnitude: " + blist.get(0).substring(blist.get(0).length() - 7, blist.get(0).length() - 4));
                        sr1Depth.setText("Depth: " + blist.get(0).substring(blist.get(0).length() - 81, blist.get(0).length() - 78) + "km");
                        sr1Cord.setText("Co-ords: Lat: " + blist.get(0).substring(blist.get(0).length() - 27, blist.get(0).length() - 21) + "  Long: " + blist.get(0).substring(blist.get(0).length() - 46, blist.get(0).length() - 40));
                        sr1Magni.setTextColor(magniColour(blist.get(0).substring(blist.get(0).length() - 7, blist.get(0).length() - 4)));
                        tempText1 = "Earthquake at: " + blist.get(0).substring(11, blist.get(0).length() - 91);

                        break;

                    case 1:
                        sr2Button.setVisibility(View.VISIBLE);
                        sr2Button.setText("Earthquake at: " + blist.get(1).substring(11, blist.get(1).length() - 91));
                        sr2Loc.setText("Location: " + blist.get(1).substring(11, blist.get(1).length() - 91));
                        sr2Date.setText("Date: " + blist.get(1).substring(blist.get(1).length() - 70, blist.get(1).length() - 59));
                        sr2Magni.setText("Magnitude: " + blist.get(1).substring(blist.get(1).length() - 7, blist.get(1).length() - 4));
                        sr2Depth.setText("Depth: " + blist.get(1).substring(blist.get(1).length() - 81, blist.get(1).length() - 78) + "km");
                        sr2Cord.setText("Co-ords: Lat: " + blist.get(1).substring(blist.get(1).length() - 27, blist.get(1).length() - 21) + "  Long: " + blist.get(1).substring(blist.get(1).length() - 46, blist.get(1).length() - 40));
                        sr2Magni.setTextColor(magniColour(blist.get(1).substring(blist.get(1).length() - 7, blist.get(1).length() - 4)));
                        tempText2 = "Earthquake at: " + blist.get(1).substring(11, blist.get(1).length() - 91);
                        break;
                    case 2:
                        sr3Button.setVisibility(View.VISIBLE);
                        sr3Button.setText("Earthquake at: " + blist.get(2).substring(11, blist.get(2).length() - 91));
                        sr3Loc.setText("Location: " + blist.get(2).substring(11, blist.get(2).length() - 91));
                        sr3Date.setText("Date: " + blist.get(2).substring(blist.get(2).length() - 70, blist.get(2).length() - 59));
                        sr3Magni.setText("Magnitude: " + blist.get(2).substring(blist.get(2).length() - 7, blist.get(2).length() - 4));
                        sr3Depth.setText("Depth: " + blist.get(2).substring(blist.get(2).length() - 81, blist.get(2).length() - 78) + "km");
                        sr3Cord.setText("Co-ords: Lat: " + blist.get(2).substring(blist.get(2).length() - 27, blist.get(2).length() - 21) + "  Long: " + blist.get(2).substring(blist.get(2).length() - 46, blist.get(2).length() - 40));
                        sr3Magni.setTextColor(magniColour(blist.get(2).substring(blist.get(2).length() - 7, blist.get(2).length() - 4)));
                        tempText3 = "Earthquake at: " + blist.get(2).substring(11, blist.get(2).length() - 91);
                        break;
                    case 3:
                        sr4Button.setVisibility(View.VISIBLE);
                        sr4Button.setText("Earthquake at: " + blist.get(3).substring(11, blist.get(3).length() - 91));
                        sr4Loc.setText("Location: " + blist.get(3).substring(11, blist.get(3).length() - 91));
                        sr4Date.setText("Date: " + blist.get(3).substring(blist.get(3).length() - 70, blist.get(3).length() - 59));
                        sr4Magni.setText("Magnitude: " + blist.get(3).substring(blist.get(3).length() - 7, blist.get(3).length() - 4));
                        sr4Depth.setText("Depth: " + blist.get(3).substring(blist.get(3).length() - 81, blist.get(3).length() - 78) + "km");
                        sr4Cord.setText("Co-ords: Lat: " + blist.get(3).substring(blist.get(3).length() - 27, blist.get(3).length() - 21) + "  Long: " + blist.get(3).substring(blist.get(3).length() - 46, blist.get(3).length() - 40));
                        sr4Magni.setTextColor(magniColour(blist.get(3).substring(blist.get(3).length() - 7, blist.get(3).length() - 4)));
                        tempText4 = "Earthquake at: " + blist.get(3).substring(11, blist.get(3).length() - 91);
                        break;
                    case 4:
                        sr5Button.setVisibility(View.VISIBLE);
                        sr5Button.setText("Earthquake at: " + blist.get(4).substring(11, blist.get(4).length() - 91));
                        sr5Loc.setText("Location: " + blist.get(4).substring(11, blist.get(4).length() - 91));
                        sr5Date.setText("Date: " + blist.get(4).substring(blist.get(4).length() - 70, blist.get(4).length() - 59));
                        sr5Magni.setText("Magnitude: " + blist.get(4).substring(blist.get(4).length() - 7, blist.get(4).length() - 4));
                        sr5Depth.setText("Depth: " + blist.get(4).substring(blist.get(4).length() - 81, blist.get(4).length() - 78) + "km");
                        sr5Cord.setText("Co-ords: Lat: " + blist.get(4).substring(blist.get(4).length() - 27, blist.get(4).length() - 21) + "  Long: " + blist.get(4).substring(blist.get(4).length() - 46, blist.get(4).length() - 40));
                        sr5Magni.setTextColor(magniColour(blist.get(4).substring(blist.get(4).length() - 7, blist.get(4).length() - 4)));
                        tempText4 = "Earthquake at: " + blist.get(4).substring(11, blist.get(4).length() - 91);
                        break;

                }
            }

    }
    public ArrayList<String> getWest() {
        String tempLong1 = "";
        String tempLong2 = "";
        Double doLong1 = 0.0;
        Double doLong2 = 0.0;
        ArrayList<String> tempResult = new ArrayList<String>(1);


        for (int i = 1; i <= alist.size() - 2; i++) {
            tempLong1 = alist.get(i).substring(alist.get(i).length() - 46, alist.get(i).length() - 40);
            tempLong2 = alist.get(i + 1).substring(alist.get(i + 1).length() - 46, alist.get(i + 1).length() - 40);

            tempLong1 = tempLong1.replaceAll("'","");
            tempLong2 = tempLong2.replaceAll("'","");
            doLong1 = Double.parseDouble(tempLong1);
            doLong2 = Double.parseDouble(tempLong2);

            if (doLong1 < ggowLong && doLong2 < ggowLong  && Math.abs(ggowLong - doLong1) < Math.abs(ggowLong - doLong2)) {
                tempResult.add("");
                tempResult.set(0, alist.get(i));
            } else if (doLong1 < ggowLong && doLong2 < ggowLong  && Math.abs(ggowLong - doLong1) > Math.abs(ggowLong - doLong2)) {
                tempResult.add("");
                tempResult.set(0, alist.get(i + 1));
            }
        }
        return tempResult;
    }

    public ArrayList<String> searchDepthBig() {
        String tempDepth1 = "";
        String tempDepth2 = "";
        Double doDepth1 = 0.0;
        Double doDepth2 = 0.0;
        Double tDepth = 0.0;
        ArrayList<String> tempResult = new ArrayList<String>(1);


        for (int i = 1; i <= alist.size() - 2; i++) {
            tempDepth1 = alist.get(i).substring(alist.get(i).length() - 81, alist.get(i).length() - 78);
            tempDepth2 = alist.get(i + 1).substring(alist.get(i + 1).length() - 81, alist.get(i + 1).length() - 78);

            tempDepth1 = tempDepth1.replaceAll("'","");
            tempDepth2 = tempDepth2.replaceAll("'","");
            doDepth1 = Double.parseDouble(tempDepth1);
            doDepth2 = Double.parseDouble(tempDepth2);


            if (tDepth <= doDepth2) {
                tDepth = doDepth2;
                tempResult.add("");
                tempResult.set(0, alist.get(i + 1));
            }

        }
        return tempResult;
    }

    public ArrayList<String> searchMagni() {
        String tempDepth1 = "";
        String tempDepth2 = "";
        Double doDepth1 = 0.0;
        Double doDepth2 = 0.0;
        Double tDepth = 0.0;
        ArrayList<String> tempResult = new ArrayList<String>(1);


        for (int i = 1; i <= alist.size() - 2; i++) {
            tempDepth1 = alist.get(i).substring(alist.get(i).length() - 7, alist.get(i).length() - 4);
            tempDepth2 = alist.get(i + 1).substring(alist.get(i + 1).length() - 7, alist.get(i + 1).length() - 4);

            tempDepth1 = tempDepth1.replaceAll("'","");
            tempDepth2 = tempDepth2.replaceAll("'","");
            doDepth1 = Double.parseDouble(tempDepth1);
            doDepth2 = Double.parseDouble(tempDepth2);


            if (tDepth <= doDepth2) {
                tDepth = doDepth2;
                tempResult.add("");
                tempResult.set(0, alist.get(i + 1));
            }

        }
        return tempResult;
    }

    public ArrayList<String> searchDepthLow() {
        String tempDepth1 = "";
        String tempDepth2 = "";
        Double doDepth1 = 0.0;
        Double doDepth2 = 0.0;
        Double tDepth = 0.0;
        ArrayList<String> tempResult = new ArrayList<String>(1);
        tDepth = 10.0;

        for (int i = 1; i <= alist.size() - 2; i++) {
            tempDepth1 = alist.get(i).substring(alist.get(i).length() - 81, alist.get(i).length() - 78);
            tempDepth2 = alist.get(i + 1).substring(alist.get(i + 1).length() - 81, alist.get(i + 1).length() - 78);

            tempDepth1 = tempDepth1.replaceAll("'","");
            tempDepth2 = tempDepth2.replaceAll("'","");
            doDepth1 = Double.parseDouble(tempDepth1);
            doDepth2 = Double.parseDouble(tempDepth2);


            if (doDepth2 < tDepth) {
                tDepth = doDepth2;
                tempResult.add("");
                tempResult.set(0, alist.get(i + 1));
            }

        }
        return tempResult;
    }



    @Override
    public void onClick(View v) {

        if (v == north) {
            fr1Button.setVisibility(View.GONE);
            fr2Button.setVisibility(View.GONE);
            fr3Button.setVisibility(View.GONE);
            fr4Button.setVisibility(View.GONE);
            fr5Button.setVisibility(View.GONE);
            fr6Button.setVisibility(View.GONE);
            fr7Button.setVisibility(View.GONE);
            fr8Button.setVisibility(View.GONE);
            fr9Button.setVisibility(View.GONE);
            fr10Button.setVisibility(View.GONE);
            sr1Button.setVisibility(View.GONE);
            sr2Button.setVisibility(View.GONE);
            sr3Button.setVisibility(View.GONE);
            sr4Button.setVisibility(View.GONE);
            sr5Button.setVisibility(View.GONE);

            ArrayList<String> northData = new ArrayList<>();
            northData = getNorth();

            sr1Button.setVisibility(View.VISIBLE);
            sr1Button.setText("Earthquake at: " + northData.get(0).substring(11, northData.get(0).length() - 91));
            sr1Loc.setText("Location: " + northData.get(0).substring(11, northData.get(0).length() - 91));
            sr1Date.setText("Date: " + northData.get(0).substring(northData.get(0).length() - 70, northData.get(0).length() - 59));
            sr1Magni.setText("Magnitude: " + northData.get(0).substring(northData.get(0).length() - 7, northData.get(0).length() - 4));
            sr1Depth.setText("Depth: " + northData.get(0).substring(northData.get(0).length() - 81, northData.get(0).length() - 78) + "km");
            sr1Cord.setText("Co-ords: Lat: " + northData.get(0).substring(northData.get(0).length() - 27, northData.get(0).length() - 21) + "  Long: " + northData.get(0).substring(northData.get(0).length() - 46, northData.get(0).length() - 40));
            sr1Magni.setTextColor(magniColour(northData.get(0).substring(northData.get(0).length() - 7, northData.get(0).length() - 4)));
            tempText1 = "Earthquake at: " + northData.get(0).substring(11, northData.get(0).length() - 91);
        }
        if (v == south) {
            fr1Button.setVisibility(View.GONE);
            fr2Button.setVisibility(View.GONE);
            fr3Button.setVisibility(View.GONE);
            fr4Button.setVisibility(View.GONE);
            fr5Button.setVisibility(View.GONE);
            fr6Button.setVisibility(View.GONE);
            fr7Button.setVisibility(View.GONE);
            fr8Button.setVisibility(View.GONE);
            fr9Button.setVisibility(View.GONE);
            fr10Button.setVisibility(View.GONE);
            sr1Button.setVisibility(View.GONE);
            sr2Button.setVisibility(View.GONE);
            sr3Button.setVisibility(View.GONE);
            sr4Button.setVisibility(View.GONE);
            sr5Button.setVisibility(View.GONE);

            ArrayList<String> southData = new ArrayList<>();
            southData = getSouth();

            sr1Button.setVisibility(View.VISIBLE);
            sr1Button.setText("Earthquake at: " + southData.get(0).substring(11, southData.get(0).length() - 91));
            sr1Loc.setText("Location: " + southData.get(0).substring(11, southData.get(0).length() - 91));
            sr1Date.setText("Date: " + southData.get(0).substring(southData.get(0).length() - 70, southData.get(0).length() - 59));
            sr1Magni.setText("Magnitude: " + southData.get(0).substring(southData.get(0).length() - 7, southData.get(0).length() - 4));
            sr1Depth.setText("Depth: " + southData.get(0).substring(southData.get(0).length() - 81, southData.get(0).length() - 78) + "km");
            sr1Cord.setText("Co-ords: Lat: " + southData.get(0).substring(southData.get(0).length() - 27, southData.get(0).length() - 21) + "  Long: " + southData.get(0).substring(southData.get(0).length() - 46, southData.get(0).length() - 40));
            sr1Magni.setTextColor(magniColour(southData.get(0).substring(southData.get(0).length() - 7, southData.get(0).length() - 4)));
            tempText1 = "Earthquake at: " + southData.get(0).substring(11, southData.get(0).length() - 91);
        }

        if (v == east) {
            fr1Button.setVisibility(View.GONE);
            fr2Button.setVisibility(View.GONE);
            fr3Button.setVisibility(View.GONE);
            fr4Button.setVisibility(View.GONE);
            fr5Button.setVisibility(View.GONE);
            fr6Button.setVisibility(View.GONE);
            fr7Button.setVisibility(View.GONE);
            fr8Button.setVisibility(View.GONE);
            fr9Button.setVisibility(View.GONE);
            fr10Button.setVisibility(View.GONE);
            sr1Button.setVisibility(View.GONE);
            sr2Button.setVisibility(View.GONE);
            sr3Button.setVisibility(View.GONE);
            sr4Button.setVisibility(View.GONE);
            sr5Button.setVisibility(View.GONE);

            ArrayList<String> eastData = new ArrayList<>();
            eastData = getEast();

            sr1Button.setVisibility(View.VISIBLE);
            sr1Button.setText("Earthquake at: " + eastData.get(0).substring(11, eastData.get(0).length() - 91));
            sr1Loc.setText("Location: " + eastData.get(0).substring(11, eastData.get(0).length() - 91));
            sr1Date.setText("Date: " + eastData.get(0).substring(eastData.get(0).length() - 70, eastData.get(0).length() - 59));
            sr1Magni.setText("Magnitude: " + eastData.get(0).substring(eastData.get(0).length() - 7, eastData.get(0).length() - 4));
            sr1Depth.setText("Depth: " + eastData.get(0).substring(eastData.get(0).length() - 81, eastData.get(0).length() - 78) + "km");
            sr1Cord.setText("Co-ords: Lat: " + eastData.get(0).substring(eastData.get(0).length() - 27, eastData.get(0).length() - 21) + "  Long: " + eastData.get(0).substring(eastData.get(0).length() - 46, eastData.get(0).length() - 40));
            sr1Magni.setTextColor(magniColour(eastData.get(0).substring(eastData.get(0).length() - 7, eastData.get(0).length() - 4)));
            tempText1 = "Earthquake at: " + eastData.get(0).substring(11, eastData.get(0).length() - 91);
        }

        if (v == west) {
            fr1Button.setVisibility(View.GONE);
            fr2Button.setVisibility(View.GONE);
            fr3Button.setVisibility(View.GONE);
            fr4Button.setVisibility(View.GONE);
            fr5Button.setVisibility(View.GONE);
            fr6Button.setVisibility(View.GONE);
            fr7Button.setVisibility(View.GONE);
            fr8Button.setVisibility(View.GONE);
            fr9Button.setVisibility(View.GONE);
            fr10Button.setVisibility(View.GONE);
            sr1Button.setVisibility(View.GONE);
            sr2Button.setVisibility(View.GONE);
            sr3Button.setVisibility(View.GONE);
            sr4Button.setVisibility(View.GONE);
            sr5Button.setVisibility(View.GONE);

            ArrayList<String> westData = new ArrayList<>();
            westData = getWest();

            sr1Button.setVisibility(View.VISIBLE);
            sr1Button.setText("Earthquake at: " + westData.get(0).substring(11, westData.get(0).length() - 91));
            sr1Loc.setText("Location: " + westData.get(0).substring(11, westData.get(0).length() - 91));
            sr1Date.setText("Date: " + westData.get(0).substring(westData.get(0).length() - 69, westData.get(0).length() - 59));
            sr1Magni.setText("Magnitude: " + westData.get(0).substring(westData.get(0).length() - 6, westData.get(0).length() - 3));
            sr1Depth.setText("Depth: " + westData.get(0).substring(westData.get(0).length() - 80, westData.get(0).length() - 78) + "km");
            sr1Cord.setText("Co-ords: Lat: " + westData.get(0).substring(westData.get(0).length() - 26, westData.get(0).length() - 20) + "  Long: " + westData.get(0).substring(westData.get(0).length() - 45, westData.get(0).length() - 39));
            sr1Magni.setTextColor(magniColour(westData.get(0).substring(westData.get(0).length() - 6, westData.get(0).length() - 3)));
            tempText1 = "Earthquake at: " + westData.get(0).substring(11, westData.get(0).length() - 91);
        }

        if (v == depthSearch) {
            fr1Button.setVisibility(View.GONE);
            fr2Button.setVisibility(View.GONE);
            fr3Button.setVisibility(View.GONE);
            fr4Button.setVisibility(View.GONE);
            fr5Button.setVisibility(View.GONE);
            fr6Button.setVisibility(View.GONE);
            fr7Button.setVisibility(View.GONE);
            fr8Button.setVisibility(View.GONE);
            fr9Button.setVisibility(View.GONE);
            fr10Button.setVisibility(View.GONE);
            sr1Button.setVisibility(View.GONE);
            sr2Button.setVisibility(View.GONE);
            sr3Button.setVisibility(View.GONE);
            sr4Button.setVisibility(View.GONE);
            sr5Button.setVisibility(View.GONE);

            ArrayList<String> depthData = new ArrayList<>();
            depthData = searchDepthBig();

            ArrayList<String> lowData = new ArrayList<>();
            lowData = searchDepthLow();

            sr1Button.setVisibility(View.VISIBLE);
            sr1Button.setText("Earthquake at: " + depthData.get(0).substring(11, depthData.get(0).length() - 92));
            sr1Loc.setText("Location: " + depthData.get(0).substring(11, depthData.get(0).length() - 92));
            sr1Date.setText("Date: " + depthData.get(0).substring(depthData.get(0).length() - 70, depthData.get(0).length() - 60));
            sr1Magni.setText("Magnitude: " + depthData.get(0).substring(depthData.get(0).length() - 7, depthData.get(0).length() - 4));
            sr1Depth.setText("Depth: " + depthData.get(0).substring(depthData.get(0).length() - 81, depthData.get(0).length() - 79) + "km");
            sr1Cord.setText("Co-ords: Lat: " + depthData.get(0).substring(depthData.get(0).length() - 26, depthData.get(0).length() - 21) + "  Long: " + depthData.get(0).substring(depthData.get(0).length() - 46, depthData.get(0).length() - 40));
            sr1Magni.setTextColor(magniColour(depthData.get(0).substring(depthData.get(0).length() - 7, depthData.get(0).length() - 4)));
            tempText1 = "Earthquake at: " + depthData.get(0).substring(11, depthData.get(0).length() - 91);

            sr2Button.setVisibility(View.VISIBLE);
            sr2Button.setText("Earthquake at: " + lowData.get(0).substring(11, lowData.get(0).length() - 91));
            sr2Loc.setText("Location: " + lowData.get(0).substring(11, lowData.get(0).length() - 91));
            sr2Date.setText("Date: " + lowData.get(0).substring(lowData.get(0).length() - 70, lowData.get(0).length() - 60));
            sr2Magni.setText("Magnitude: " + lowData.get(0).substring(lowData.get(0).length() - 7, lowData.get(0).length() - 4));
            sr2Depth.setText("Depth: " + lowData.get(0).substring(lowData.get(0).length() - 81, lowData.get(0).length() - 79) + "km");
            sr2Cord.setText("Co-ords: Lat: " + lowData.get(0).substring(lowData.get(0).length() - 26, lowData.get(0).length() - 21) + "  Long: " + lowData.get(0).substring(lowData.get(0).length() - 46, lowData.get(0).length() - 40));
            sr2Magni.setTextColor(magniColour(lowData.get(0).substring(lowData.get(0).length() - 7, lowData.get(0).length() - 4)));
            tempText2 = "Earthquake at: " + lowData.get(0).substring(11, lowData.get(0).length() - 91);
        }

        if (v == magniSearch) {
            fr1Button.setVisibility(View.GONE);
            fr2Button.setVisibility(View.GONE);
            fr3Button.setVisibility(View.GONE);
            fr4Button.setVisibility(View.GONE);
            fr5Button.setVisibility(View.GONE);
            fr6Button.setVisibility(View.GONE);
            fr7Button.setVisibility(View.GONE);
            fr8Button.setVisibility(View.GONE);
            fr9Button.setVisibility(View.GONE);
            fr10Button.setVisibility(View.GONE);
            sr1Button.setVisibility(View.GONE);
            sr2Button.setVisibility(View.GONE);
            sr3Button.setVisibility(View.GONE);
            sr4Button.setVisibility(View.GONE);
            sr5Button.setVisibility(View.GONE);

            ArrayList<String> magniData = new ArrayList<>();
            magniData = searchMagni();

            sr1Button.setVisibility(View.VISIBLE);
            sr1Button.setText("Earthquake at: " + magniData.get(0).substring(11, magniData.get(0).length() - 91));
            sr1Loc.setText("Location: " + magniData.get(0).substring(11, magniData.get(0).length() - 91));
            sr1Date.setText("Date: " + magniData.get(0).substring(magniData.get(0).length() - 70, magniData.get(0).length() - 59));
            sr1Magni.setText("Magnitude: " + magniData.get(0).substring(magniData.get(0).length() - 7, magniData.get(0).length() - 4));
            sr1Depth.setText("Depth: " + magniData.get(0).substring(magniData.get(0).length() - 81, magniData.get(0).length() - 78) + "km");
            sr1Cord.setText("Co-ords: Lat: " + magniData.get(0).substring(magniData.get(0).length() - 27, magniData.get(0).length() - 21) + "  Long: " + magniData.get(0).substring(magniData.get(0).length() - 46, magniData.get(0).length() - 40));
            sr1Magni.setTextColor(magniColour(magniData.get(0).substring(magniData.get(0).length() - 7, magniData.get(0).length() - 4)));
            tempText1 = "Earthquake at: " + magniData.get(0).substring(11, magniData.get(0).length() - 91);
        }

        if (v == dateButton) {
            Editable aDate = searchDate.getText();
            String item = aDate.toString();

            Editable aLoc = searchLoc.getText();
            String locItem = aLoc.toString();

            ArrayList<String> dateList = new ArrayList<>();
            ArrayList<String> locList = new ArrayList<>();
            ArrayList<String> locNoList = new ArrayList<>();
            dateList = getSearchDate(item);
            locList = getSearchLoc(dateList, locItem);
            locNoList = getSearchLoc(alist, locItem);

            fr1Button.setVisibility(View.GONE);
            fr2Button.setVisibility(View.GONE);
            fr3Button.setVisibility(View.GONE);
            fr4Button.setVisibility(View.GONE);
            fr5Button.setVisibility(View.GONE);
            fr6Button.setVisibility(View.GONE);
            fr7Button.setVisibility(View.GONE);
            fr8Button.setVisibility(View.GONE);
            fr9Button.setVisibility(View.GONE);
            fr10Button.setVisibility(View.GONE);

            if (locItem.length() == 0) {

                for (int i = 0; i <= dateList.size() - 1; i++) {
                    switch (i) {
                        case 0:
                            sr1Button.setVisibility(View.VISIBLE);
                            sr1Button.setText("Earthquake at: " + dateList.get(0).substring(11, dateList.get(0).length() - 91));
                            sr1Loc.setText("Location: " + dateList.get(0).substring(11, dateList.get(0).length() - 91));
                            sr1Date.setText("Date: " + dateList.get(0).substring(dateList.get(0).length() - 70, dateList.get(0).length() - 59));
                            sr1Magni.setText("Magnitude: " + dateList.get(0).substring(dateList.get(0).length() - 7, dateList.get(0).length() - 4));
                            sr1Depth.setText("Depth: " + dateList.get(0).substring(dateList.get(0).length() - 81, dateList.get(0).length() - 78) + "km");
                            sr1Cord.setText("Co-ords: Lat: " + dateList.get(0).substring(dateList.get(0).length() - 27, dateList.get(0).length() - 21) + "  Long: " + dateList.get(0).substring(dateList.get(0).length() - 46, dateList.get(0).length() - 40));
                            sr1Magni.setTextColor(magniColour(dateList.get(0).substring(dateList.get(0).length() - 7, dateList.get(0).length() - 4)));
                            tempText1 = "Earthquake at: " + dateList.get(0).substring(11, dateList.get(0).length() - 91);

                            break;

                        case 1:
                            sr2Button.setVisibility(View.VISIBLE);
                            sr2Button.setText("Earthquake at: " + dateList.get(1).substring(11, dateList.get(1).length() - 91));
                            sr2Loc.setText("Location: " + dateList.get(1).substring(11, dateList.get(1).length() - 91));
                            sr2Date.setText("Date: " + dateList.get(1).substring(dateList.get(1).length() - 70, dateList.get(1).length() - 59));
                            sr2Magni.setText("Magnitude: " + dateList.get(1).substring(dateList.get(1).length() - 7, dateList.get(1).length() - 4));
                            sr2Depth.setText("Depth: " + dateList.get(1).substring(dateList.get(1).length() - 81, dateList.get(1).length() - 78) + "km");
                            sr2Cord.setText("Co-ords: Lat: " + dateList.get(1).substring(dateList.get(1).length() - 27, dateList.get(1).length() - 21) + "  Long: " + dateList.get(1).substring(dateList.get(1).length() - 46, dateList.get(1).length() - 40));
                            sr2Magni.setTextColor(magniColour(dateList.get(1).substring(dateList.get(1).length() - 7, dateList.get(1).length() - 4)));
                            tempText2 = "Earthquake at: " + dateList.get(1).substring(11, dateList.get(1).length() - 91);
                            break;
                        case 2:
                            sr3Button.setVisibility(View.VISIBLE);
                            sr3Button.setText("Earthquake at: " + dateList.get(2).substring(11, dateList.get(2).length() - 91));
                            sr3Loc.setText("Location: " + dateList.get(2).substring(11, dateList.get(2).length() - 91));
                            sr3Date.setText("Date: " + dateList.get(2).substring(dateList.get(2).length() - 70, dateList.get(2).length() - 59));
                            sr3Magni.setText("Magnitude: " + dateList.get(2).substring(dateList.get(2).length() - 7, dateList.get(2).length() - 4));
                            sr3Depth.setText("Depth: " + dateList.get(2).substring(dateList.get(2).length() - 81, dateList.get(2).length() - 78) + "km");
                            sr3Cord.setText("Co-ords: Lat: " + dateList.get(2).substring(dateList.get(2).length() - 27, dateList.get(2).length() - 21) + "  Long: " + dateList.get(2).substring(dateList.get(2).length() - 46, dateList.get(2).length() - 40));
                            sr3Magni.setTextColor(magniColour(dateList.get(2).substring(dateList.get(2).length() - 7, dateList.get(2).length() - 4)));
                            tempText3 = "Earthquake at: " + dateList.get(2).substring(11, dateList.get(2).length() - 91);
                            break;
                        case 3:
                            sr4Button.setVisibility(View.VISIBLE);
                            sr4Button.setText("Earthquake at: " + dateList.get(3).substring(11, dateList.get(3).length() - 91));
                            sr4Loc.setText("Location: " + dateList.get(3).substring(11, dateList.get(3).length() - 91));
                            sr4Date.setText("Date: " + dateList.get(3).substring(dateList.get(3).length() - 70, dateList.get(3).length() - 59));
                            sr4Magni.setText("Magnitude: " + dateList.get(3).substring(dateList.get(3).length() - 7, dateList.get(3).length() - 4));
                            sr4Depth.setText("Depth: " + dateList.get(3).substring(dateList.get(3).length() - 81, dateList.get(3).length() - 78) + "km");
                            sr4Cord.setText("Co-ords: Lat: " + dateList.get(3).substring(dateList.get(3).length() - 27, dateList.get(3).length() - 21) + "  Long: " + dateList.get(3).substring(dateList.get(3).length() - 46, dateList.get(3).length() - 40));
                            sr4Magni.setTextColor(magniColour(dateList.get(3).substring(dateList.get(3).length() - 7, dateList.get(3).length() - 4)));
                            tempText4 = "Earthquake at: " + dateList.get(3).substring(11, dateList.get(3).length() - 91);
                            break;
                        case 4:
                            sr5Button.setVisibility(View.VISIBLE);
                            sr5Button.setText("Earthquake at: " + dateList.get(4).substring(11, dateList.get(4).length() - 91));
                            sr5Loc.setText("Location: " + dateList.get(4).substring(11, dateList.get(4).length() - 91));
                            sr5Date.setText("Date: " + dateList.get(4).substring(dateList.get(4).length() - 70, dateList.get(4).length() - 59));
                            sr5Magni.setText("Magnitude: " + dateList.get(4).substring(dateList.get(4).length() - 7, dateList.get(4).length() - 4));
                            sr5Depth.setText("Depth: " + dateList.get(4).substring(dateList.get(4).length() - 81, dateList.get(4).length() - 78) + "km");
                            sr5Cord.setText("Co-ords: Lat: " + dateList.get(4).substring(dateList.get(4).length() - 27, dateList.get(4).length() - 21) + "  Long: " + dateList.get(4).substring(dateList.get(4).length() - 46, dateList.get(4).length() - 40));
                            sr5Magni.setTextColor(magniColour(dateList.get(4).substring(dateList.get(4).length() - 7, dateList.get(4).length() - 4)));
                            tempText4 = "Earthquake at: " + dateList.get(4).substring(11, dateList.get(4).length() - 91);
                            break;

                    }
                }
            } else if (item.length() == 0){
                sr1Button.setVisibility(View.GONE);
                sr2Button.setVisibility(View.GONE);
                sr3Button.setVisibility(View.GONE);
                sr4Button.setVisibility(View.GONE);
                sr5Button.setVisibility(View.GONE);
                updateLocSearch(locNoList);

            } else {
                sr1Button.setVisibility(View.GONE);
                sr2Button.setVisibility(View.GONE);
                sr3Button.setVisibility(View.GONE);
                sr4Button.setVisibility(View.GONE);
                sr5Button.setVisibility(View.GONE);
                for (int i = 0; i <= locList.size() - 1; i++) {
                    switch (i) {
                        case 0:
                            sr1Button.setVisibility(View.VISIBLE);
                            sr1Button.setText("Earthquake at: " + locList.get(0).substring(11, locList.get(0).length() - 91));
                            sr1Loc.setText("Location: " + locList.get(0).substring(11, locList.get(0).length() - 91));
                            sr1Date.setText("Date: " + locList.get(0).substring(locList.get(0).length() - 70, locList.get(0).length() - 59));
                            sr1Magni.setText("Magnitude: " + locList.get(0).substring(locList.get(0).length() - 7, locList.get(0).length() - 4));
                            sr1Depth.setText("Depth: " + locList.get(0).substring(locList.get(0).length() - 81, locList.get(0).length() - 78) + "km");
                            sr1Cord.setText("Co-ords: Lat: " + locList.get(0).substring(locList.get(0).length() - 27, locList.get(0).length() - 21) + "  Long: " + locList.get(0).substring(locList.get(0).length() - 46, locList.get(0).length() - 40));
                            sr1Magni.setTextColor(magniColour(locList.get(0).substring(locList.get(0).length() - 7, locList.get(0).length() - 4)));
                            tempText1 = "Earthquake at: " + locList.get(0).substring(11, locList.get(0).length() - 91);

                            break;

                        case 1:
                            sr2Button.setVisibility(View.VISIBLE);
                            sr2Button.setText("Earthquake at: " + locList.get(1).substring(11, locList.get(1).length() - 91));
                            sr2Loc.setText("Location: " + locList.get(1).substring(11, locList.get(1).length() - 91));
                            sr2Date.setText("Date: " + locList.get(1).substring(locList.get(1).length() - 70, locList.get(1).length() - 59));
                            sr2Magni.setText("Magnitude: " + locList.get(1).substring(locList.get(1).length() - 7, locList.get(1).length() - 4));
                            sr2Depth.setText("Depth: " + locList.get(1).substring(locList.get(1).length() - 81, locList.get(1).length() - 78) + "km");
                            sr2Cord.setText("Co-ords: Lat: " + locList.get(1).substring(locList.get(1).length() - 27, locList.get(1).length() - 21) + "  Long: " + locList.get(1).substring(locList.get(1).length() - 46, locList.get(1).length() - 40));
                            sr2Magni.setTextColor(magniColour(locList.get(1).substring(locList.get(1).length() - 7, locList.get(1).length() - 4)));
                            tempText2 = "Earthquake at: " + locList.get(1).substring(11, locList.get(1).length() - 91);
                            break;
                        case 2:
                            sr3Button.setVisibility(View.VISIBLE);
                            sr3Button.setText("Earthquake at: " + locList.get(2).substring(11, locList.get(2).length() - 91));
                            sr3Loc.setText("Location: " + locList.get(2).substring(11, locList.get(2).length() - 91));
                            sr3Date.setText("Date: " + locList.get(2).substring(locList.get(2).length() - 70, locList.get(2).length() - 59));
                            sr3Magni.setText("Magnitude: " + locList.get(2).substring(locList.get(2).length() - 7, locList.get(2).length() - 4));
                            sr3Depth.setText("Depth: " + locList.get(2).substring(locList.get(2).length() - 81, locList.get(2).length() - 78) + "km");
                            sr3Cord.setText("Co-ords: Lat: " + locList.get(2).substring(locList.get(2).length() - 27, locList.get(2).length() - 21) + "  Long: " + locList.get(2).substring(locList.get(2).length() - 46, locList.get(2).length() - 40));
                            sr3Magni.setTextColor(magniColour(locList.get(2).substring(locList.get(2).length() - 7, locList.get(2).length() - 4)));
                            tempText3 = "Earthquake at: " + locList.get(2).substring(11, locList.get(2).length() - 91);
                            break;
                        case 3:
                            sr4Button.setVisibility(View.VISIBLE);
                            sr4Button.setText("Earthquake at: " + locList.get(3).substring(11, locList.get(3).length() - 91));
                            sr4Loc.setText("Location: " + locList.get(3).substring(11, locList.get(3).length() - 91));
                            sr4Date.setText("Date: " + locList.get(3).substring(locList.get(3).length() - 70, locList.get(3).length() - 59));
                            sr4Magni.setText("Magnitude: " + locList.get(3).substring(locList.get(3).length() - 7, locList.get(3).length() - 4));
                            sr4Depth.setText("Depth: " + locList.get(3).substring(locList.get(3).length() - 81, locList.get(3).length() - 78) + "km");
                            sr4Cord.setText("Co-ords: Lat: " + locList.get(3).substring(locList.get(3).length() - 27, locList.get(3).length() - 21) + "  Long: " + locList.get(3).substring(locList.get(3).length() - 46, locList.get(3).length() - 40));
                            sr4Magni.setTextColor(magniColour(locList.get(3).substring(locList.get(3).length() - 7, locList.get(3).length() - 4)));
                            tempText4 = "Earthquake at: " + locList.get(3).substring(11, locList.get(3).length() - 91);
                            break;
                        case 4:
                            sr5Button.setVisibility(View.VISIBLE);
                            sr5Button.setText("Earthquake at: " + locList.get(4).substring(11, locList.get(4).length() - 91));
                            sr5Loc.setText("Location: " + locList.get(4).substring(11, locList.get(4).length() - 91));
                            sr5Date.setText("Date: " + locList.get(4).substring(locList.get(4).length() - 70, locList.get(4).length() - 59));
                            sr5Magni.setText("Magnitude: " + locList.get(4).substring(locList.get(4).length() - 7, locList.get(4).length() - 4));
                            sr5Depth.setText("Depth: " + locList.get(4).substring(locList.get(4).length() - 81, locList.get(4).length() - 78) + "km");
                            sr5Cord.setText("Co-ords: Lat: " + locList.get(4).substring(locList.get(4).length() - 27, locList.get(4).length() - 21) + "  Long: " + locList.get(4).substring(locList.get(4).length() - 46, locList.get(4).length() - 40));
                            sr5Magni.setTextColor(magniColour(locList.get(4).substring(locList.get(4).length() - 7, locList.get(4).length() - 4)));
                            tempText4 = "Earthquake at: " + locList.get(4).substring(11, locList.get(4).length() - 91);
                            break;

                    }
                }

            }
            // alist.get(entryNum + value).length() - 70, alist.get(entryNum + value).length() - 59


            System.out.println(alist);
        }



        if (v == sr1Button) {

            if (sr1Button.isChecked()) {
                sr1Loc.setVisibility(View.VISIBLE);
                sr1Date.setVisibility(View.VISIBLE);
                sr1Cord.setVisibility(View.VISIBLE);
                sr1Magni.setVisibility(View.VISIBLE);
                sr1Depth.setVisibility(View.VISIBLE);
                sr1Button.setText(tempText1);

            } else {
                sr1Loc.setVisibility(View.GONE);
                sr1Date.setVisibility(View.GONE);
                sr1Cord.setVisibility(View.GONE);
                sr1Magni.setVisibility(View.GONE);
                sr1Depth.setVisibility(View.GONE);
                sr1Button.setText(tempText1);
            }
        }
        if (v == sr2Button) {

            if (sr2Button.isChecked()) {
                sr2Loc.setVisibility(View.VISIBLE);
                sr2Date.setVisibility(View.VISIBLE);
                sr2Cord.setVisibility(View.VISIBLE);
                sr2Magni.setVisibility(View.VISIBLE);
                sr2Depth.setVisibility(View.VISIBLE);
                sr2Button.setText(tempText2);

            } else {
                sr2Loc.setVisibility(View.GONE);
                sr2Date.setVisibility(View.GONE);
                sr2Cord.setVisibility(View.GONE);
                sr2Magni.setVisibility(View.GONE);
                sr2Depth.setVisibility(View.GONE);
                sr2Button.setText(tempText2);
            }
        }
        if (v == sr3Button) {

            if (sr3Button.isChecked()) {
                sr3Loc.setVisibility(View.VISIBLE);
                sr3Date.setVisibility(View.VISIBLE);
                sr3Cord.setVisibility(View.VISIBLE);
                sr3Magni.setVisibility(View.VISIBLE);
                sr3Depth.setVisibility(View.VISIBLE);
                sr3Button.setText(tempText3);

            } else {
                sr3Loc.setVisibility(View.GONE);
                sr3Date.setVisibility(View.GONE);
                sr3Cord.setVisibility(View.GONE);
                sr3Magni.setVisibility(View.GONE);
                sr3Depth.setVisibility(View.GONE);
                sr3Button.setText(tempText3);
            }
        }
        if (v == sr4Button) {

            if (sr4Button.isChecked()) {
                sr4Loc.setVisibility(View.VISIBLE);
                sr4Date.setVisibility(View.VISIBLE);
                sr4Cord.setVisibility(View.VISIBLE);
                sr4Magni.setVisibility(View.VISIBLE);
                sr4Depth.setVisibility(View.VISIBLE);
                sr4Button.setText(tempText4);

            } else {
                sr4Loc.setVisibility(View.GONE);
                sr4Date.setVisibility(View.GONE);
                sr4Cord.setVisibility(View.GONE);
                sr4Magni.setVisibility(View.GONE);
                sr4Depth.setVisibility(View.GONE);
                sr4Button.setText(tempText4);
            }
        }
        if (v == sr5Button) {

            if (sr5Button.isChecked()) {
                sr5Loc.setVisibility(View.VISIBLE);
                sr5Date.setVisibility(View.VISIBLE);
                sr5Cord.setVisibility(View.VISIBLE);
                sr5Magni.setVisibility(View.VISIBLE);
                sr5Depth.setVisibility(View.VISIBLE);
                sr5Button.setText(tempText5);

            } else {
                sr5Loc.setVisibility(View.GONE);
                sr5Date.setVisibility(View.GONE);
                sr5Cord.setVisibility(View.GONE);
                sr5Magni.setVisibility(View.GONE);
                sr5Depth.setVisibility(View.GONE);
                sr5Button.setText(tempText5);
            }
        }

        if (v == clearSearch) {

            sr1Button.setVisibility(View.GONE);
            sr2Button.setVisibility(View.GONE);
            sr3Button.setVisibility(View.GONE);
            sr4Button.setVisibility(View.GONE);
            sr5Button.setVisibility(View.GONE);

            fr1Button.setVisibility(View.VISIBLE);
            fr2Button.setVisibility(View.VISIBLE);
            fr3Button.setVisibility(View.VISIBLE);
            fr4Button.setVisibility(View.VISIBLE);
            fr5Button.setVisibility(View.VISIBLE);
            fr6Button.setVisibility(View.VISIBLE);
            fr7Button.setVisibility(View.VISIBLE);
            fr8Button.setVisibility(View.VISIBLE);
            fr9Button.setVisibility(View.VISIBLE);
            fr10Button.setVisibility(View.VISIBLE);
            searchDate.setText("");
            searchLoc.setText("");

        }


        if (v == nextButton) {
            page ++;
            switch (page){
                case 0:
                    fr1Button.setText("Earthquake at: " + alist.get(1).substring(11, alist.get(1).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(2).substring(11, alist.get(2).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(3).substring(11, alist.get(3).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(4).substring(11, alist.get(4).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(5).substring(11, alist.get(5).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(6).substring(11, alist.get(6).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(7).substring(11, alist.get(7).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(8).substring(11, alist.get(8).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(9).substring(11, alist.get(9).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(10).substring(11, alist.get(10).length() - 91));
                    pageNum.setText("1-10");
                    fr4Button.setVisibility(View.VISIBLE);
                    fr5Button.setVisibility(View.VISIBLE);
                    fr6Button.setVisibility(View.VISIBLE);
                    fr7Button.setVisibility(View.VISIBLE);
                    fr8Button.setVisibility(View.VISIBLE);
                    fr9Button.setVisibility(View.VISIBLE);
                    fr10Button.setVisibility(View.VISIBLE);


                    break;
                case 1:
                    fr1Button.setText("Earthquake at: " + alist.get(11).substring(11, alist.get(11).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(12).substring(11, alist.get(12).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(13).substring(11, alist.get(13).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(14).substring(11, alist.get(14).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(15).substring(11, alist.get(15).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(16).substring(11, alist.get(16).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(17).substring(11, alist.get(17).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(18).substring(11, alist.get(18).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(19).substring(11, alist.get(19).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(20).substring(11, alist.get(20).length() - 91));
                    pageNum.setText("11-20");
                    break;
                case 2:
                    fr1Button.setText("Earthquake at: " + alist.get(21).substring(11, alist.get(21).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(22).substring(11, alist.get(22).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(23).substring(11, alist.get(23).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(24).substring(11, alist.get(24).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(25).substring(11, alist.get(25).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(26).substring(11, alist.get(26).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(27).substring(11, alist.get(27).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(28).substring(11, alist.get(28).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(29).substring(11, alist.get(29).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(30).substring(11, alist.get(30).length() - 91));
                    pageNum.setText("21-30");
                    break;
                case 3:
                    fr1Button.setText("Earthquake at: " + alist.get(31).substring(11, alist.get(31).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(32).substring(11, alist.get(32).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(33).substring(11, alist.get(33).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(34).substring(11, alist.get(34).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(35).substring(11, alist.get(35).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(36).substring(11, alist.get(36).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(37).substring(11, alist.get(37).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(38).substring(11, alist.get(38).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(39).substring(11, alist.get(39).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(40).substring(11, alist.get(40).length() - 91));
                    pageNum.setText("31-40");
                    break;
                case 4:
                    fr1Button.setText("Earthquake at: " + alist.get(41).substring(11, alist.get(41).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(42).substring(11, alist.get(42).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(43).substring(11, alist.get(43).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(44).substring(11, alist.get(44).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(45).substring(11, alist.get(45).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(46).substring(11, alist.get(46).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(47).substring(11, alist.get(47).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(48).substring(11, alist.get(48).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(49).substring(11, alist.get(49).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(50).substring(11, alist.get(50).length() - 91));
                    pageNum.setText("41-50");
                    break;
                case 5:
                    fr1Button.setText("Earthquake at: " + alist.get(51).substring(11, alist.get(51).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(52).substring(11, alist.get(52).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(53).substring(11, alist.get(53).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(54).substring(11, alist.get(54).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(55).substring(11, alist.get(55).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(56).substring(11, alist.get(56).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(57).substring(11, alist.get(57).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(58).substring(11, alist.get(58).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(59).substring(11, alist.get(59).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(60).substring(11, alist.get(60).length() - 91));
                    pageNum.setText("51-60");
                    break;
                case 6:
                    fr1Button.setText("Earthquake at: " + alist.get(61).substring(11, alist.get(61).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(62).substring(11, alist.get(62).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(63).substring(11, alist.get(63).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(64).substring(11, alist.get(64).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(65).substring(11, alist.get(65).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(66).substring(11, alist.get(66).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(67).substring(11, alist.get(67).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(68).substring(11, alist.get(68).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(69).substring(11, alist.get(69).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(70).substring(11, alist.get(70).length() - 91));
                    pageNum.setText("61-70");
                    break;
                case 7:
                    fr1Button.setText("Earthquake at: " + alist.get(71).substring(11, alist.get(71).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(72).substring(11, alist.get(72).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(73).substring(11, alist.get(73).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(74).substring(11, alist.get(73).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(75).substring(11, alist.get(73).length() - 91));

                    fr6Button.setVisibility(View.GONE);
                    fr7Button.setVisibility(View.GONE);
                    fr8Button.setVisibility(View.GONE);
                    fr9Button.setVisibility(View.GONE);
                    fr10Button.setVisibility(View.GONE);
                    pageNum.setText("71-74");


            }
            if (page > 7) {
                page = 7;
            }

        }
        if (v == backButton) {
            page --;
            switch (page){
                case 0:
                    fr1Button.setText("Earthquake at: " + alist.get(1).substring(11, alist.get(1).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(2).substring(11, alist.get(2).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(3).substring(11, alist.get(3).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(4).substring(11, alist.get(4).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(5).substring(11, alist.get(5).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(6).substring(11, alist.get(6).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(7).substring(11, alist.get(7).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(8).substring(11, alist.get(8).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(9).substring(11, alist.get(9).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(10).substring(11, alist.get(10).length() - 91));
                    pageNum.setText("1-10");


                    break;
                case 1:
                    fr1Button.setText("Earthquake at: " + alist.get(11).substring(11, alist.get(11).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(12).substring(11, alist.get(12).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(13).substring(11, alist.get(13).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(14).substring(11, alist.get(14).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(15).substring(11, alist.get(15).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(16).substring(11, alist.get(16).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(17).substring(11, alist.get(17).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(18).substring(11, alist.get(18).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(19).substring(11, alist.get(19).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(20).substring(11, alist.get(20).length() - 91));
                    pageNum.setText("11-20");
                    break;
                case 2:
                    fr1Button.setText("Earthquake at: " + alist.get(21).substring(11, alist.get(21).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(22).substring(11, alist.get(22).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(23).substring(11, alist.get(23).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(24).substring(11, alist.get(24).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(25).substring(11, alist.get(25).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(26).substring(11, alist.get(26).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(27).substring(11, alist.get(27).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(28).substring(11, alist.get(28).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(29).substring(11, alist.get(29).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(30).substring(11, alist.get(30).length() - 91));
                    pageNum.setText("21-30");
                    break;
                case 3:
                    fr1Button.setText("Earthquake at: " + alist.get(31).substring(11, alist.get(31).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(32).substring(11, alist.get(32).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(33).substring(11, alist.get(33).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(34).substring(11, alist.get(34).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(35).substring(11, alist.get(35).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(36).substring(11, alist.get(36).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(37).substring(11, alist.get(37).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(38).substring(11, alist.get(38).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(39).substring(11, alist.get(39).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(40).substring(11, alist.get(40).length() - 91));
                    pageNum.setText("31-40");
                    break;
                case 4:
                    fr1Button.setText("Earthquake at: " + alist.get(41).substring(11, alist.get(41).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(42).substring(11, alist.get(42).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(43).substring(11, alist.get(43).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(44).substring(11, alist.get(44).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(45).substring(11, alist.get(45).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(46).substring(11, alist.get(46).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(47).substring(11, alist.get(47).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(48).substring(11, alist.get(48).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(49).substring(11, alist.get(49).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(50).substring(11, alist.get(50).length() - 91));
                    pageNum.setText("41-50");
                    break;
                case 5:
                    fr1Button.setText("Earthquake at: " + alist.get(51).substring(11, alist.get(51).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(52).substring(11, alist.get(52).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(53).substring(11, alist.get(53).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(54).substring(11, alist.get(54).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(55).substring(11, alist.get(55).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(56).substring(11, alist.get(56).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(57).substring(11, alist.get(57).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(58).substring(11, alist.get(58).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(59).substring(11, alist.get(59).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(60).substring(11, alist.get(60).length() - 91));
                    pageNum.setText("51-60");
                    break;
                case 6:
                    fr1Button.setText("Earthquake at: " + alist.get(61).substring(11, alist.get(61).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(62).substring(11, alist.get(62).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(63).substring(11, alist.get(63).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(64).substring(11, alist.get(64).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(65).substring(11, alist.get(65).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(66).substring(11, alist.get(66).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(67).substring(11, alist.get(67).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(68).substring(11, alist.get(68).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(69).substring(11, alist.get(69).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(70).substring(11, alist.get(70).length() - 91));
                    pageNum.setText("61-70");
                    fr4Button.setVisibility(View.VISIBLE);
                    fr5Button.setVisibility(View.VISIBLE);
                    fr6Button.setVisibility(View.VISIBLE);
                    fr7Button.setVisibility(View.VISIBLE);
                    fr8Button.setVisibility(View.VISIBLE);
                    fr9Button.setVisibility(View.VISIBLE);
                    fr10Button.setVisibility(View.VISIBLE);
                    break;
                case 7:
                    fr1Button.setText("Earthquake at: " + alist.get(71).substring(11, alist.get(71).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(72).substring(11, alist.get(72).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(73).substring(11, alist.get(73).length() - 91));
                    pageNum.setText("71-74");

                case 8:
                    page = 0;
                    fr1Button.setText("Earthquake at: " + alist.get(1).substring(11, alist.get(1).length() - 91));
                    fr2Button.setText("Earthquake at: " + alist.get(2).substring(11, alist.get(2).length() - 91));
                    fr3Button.setText("Earthquake at: " + alist.get(3).substring(11, alist.get(3).length() - 91));
                    fr4Button.setText("Earthquake at: " + alist.get(4).substring(11, alist.get(4).length() - 91));
                    fr5Button.setText("Earthquake at: " + alist.get(5).substring(11, alist.get(5).length() - 91));
                    fr6Button.setText("Earthquake at: " + alist.get(6).substring(11, alist.get(6).length() - 91));
                    fr7Button.setText("Earthquake at: " + alist.get(7).substring(11, alist.get(7).length() - 91));
                    fr8Button.setText("Earthquake at: " + alist.get(8).substring(11, alist.get(8).length() - 91));
                    fr9Button.setText("Earthquake at: " + alist.get(9).substring(11, alist.get(9).length() - 91));
                    fr10Button.setText("Earthquake at: " + alist.get(10).substring(11, alist.get(10).length() - 91));
                    pageNum.setText("1-10");
            }
            if (page < 0) {
                page = 0;
            }


        }


        if (v == fr1Button) {
            if (page == 0) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(1).substring(11, alist.get(1).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(1).substring(11, alist.get(1).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(0, 1));
                fr1Date.setText("Date: " + getDate(0, 1));
                fr1Magni.setText("Magnitude: " + getMagni(0, 1));
                fr1Depth.setText("Depth: " + getDepth(0, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(0, 1) + "  Long: " + getLong(0, 1));
                fr1Magni.setTextColor(magniColour(getMagni(0, 1)));


            }
            if (page == 1) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(11).substring(11, alist.get(11).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(11).substring(11, alist.get(11).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(1, 1));
                fr1Date.setText("Date: " + getDate(1, 1));
                fr1Magni.setText("Magnitude: " + getMagni(1, 1));
                fr1Depth.setText("Depth: " + getDepth(1, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(1, 1) + "  Long: " + getLong(1, 1));
                fr1Magni.setTextColor(magniColour(getMagni(1, 1)));

            }
            if (page == 2) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(21).substring(11, alist.get(21).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(21).substring(11, alist.get(21).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(2, 1));
                fr1Date.setText("Date: " + getDate(2, 1));
                fr1Magni.setText("Magnitude: " + getMagni(2, 1));
                fr1Depth.setText("Depth: " + getDepth(2, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(2, 1) + "  Long: " + getLong(2, 1));
                fr1Magni.setTextColor(magniColour(getMagni(2, 1)));
            }
            if (page == 3) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(31).substring(11, alist.get(31).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(31).substring(11, alist.get(31).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(3, 1));
                fr1Date.setText("Date: " + getDate(3, 1));
                fr1Magni.setText("Magnitude: " + getMagni(3, 1));
                fr1Depth.setText("Depth: " + getDepth(3, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(3, 1) + "  Long: " + getLong(3, 1));
                fr1Magni.setTextColor(magniColour(getMagni(3, 1)));

            }
            if (page == 4) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(41).substring(11, alist.get(41).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(41).substring(11, alist.get(41).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(4, 1));
                fr1Date.setText("Date: " + getDate(4, 1));
                fr1Magni.setText("Magnitude: " + getMagni(4, 1));
                fr1Depth.setText("Depth: " + getDepth(4, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(4, 1) + "  Long: " + getLong(4, 1));
                fr1Magni.setTextColor(magniColour(getMagni(4, 1)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(51).substring(11, alist.get(51).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(51).substring(11, alist.get(51).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(5, 1));
                fr1Date.setText("Date: " + getDate(5, 1));
                fr1Magni.setText("Magnitude: " + getMagni(5, 1));
                fr1Depth.setText("Depth: " + getDepth(5, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(5, 1) + "  Long: " + getLong(5, 1));
                fr1Magni.setTextColor(magniColour(getMagni(5, 1)));

            }
            if (page == 6) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(61).substring(11, alist.get(61).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(61).substring(11, alist.get(61).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(6, 1));
                fr1Date.setText("Date: " + getDate(6, 1));
                fr1Magni.setText("Magnitude: " + getMagni(6, 1));
                fr1Depth.setText("Depth: " + getDepth(6, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(6, 1) + "  Long: " + getLong(6, 1));
                fr1Magni.setTextColor(magniColour(getMagni(6, 1)));

            }
            if (page == 7) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(71).substring(11, alist.get(71).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(71).substring(11, alist.get(71).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(7, 1));
                fr1Date.setText("Date: " + getDate(7, 1));
                fr1Magni.setText("Magnitude: " + getMagni(7, 1));
                fr1Depth.setText("Depth: " + getDepth(7, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(7, 1) + "  Long: " + getLong(7, 1));
                fr1Magni.setTextColor(magniColour(getMagni(7, 1)));

            }
            if (page == 8) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(81).substring(11, alist.get(81).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(81).substring(11, alist.get(81).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(8, 1));
                fr1Date.setText("Date: " + getDate(8, 1));
                fr1Magni.setText("Magnitude: " + getMagni(8, 1));
                fr1Depth.setText("Depth: " + getDepth(8, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(8, 1) + "  Long: " + getLong(8, 1));
                fr1Magni.setTextColor(magniColour(getMagni(8, 1)));

            }
            if (page == 9) {
                if (fr1Button.isChecked()) {
                    fr1Loc.setVisibility(View.VISIBLE);
                    fr1Date.setVisibility(View.VISIBLE);
                    fr1Cord.setVisibility(View.VISIBLE);
                    fr1Magni.setVisibility(View.VISIBLE);
                    fr1Depth.setVisibility(View.VISIBLE);
                    fr1Button.setText("Earthquake at: " + alist.get(91).substring(11, alist.get(91).length() - 91));

                } else {
                    fr1Loc.setVisibility(View.GONE);
                    fr1Date.setVisibility(View.GONE);
                    fr1Cord.setVisibility(View.GONE);
                    fr1Magni.setVisibility(View.GONE);
                    fr1Depth.setVisibility(View.GONE);
                    fr1Button.setText("Earthquake at: " + alist.get(91).substring(11, alist.get(91).length() - 91));
                }


                fr1Loc.setText("Location: " + getLoc(9, 1));
                fr1Date.setText("Date: " + getDate(9, 1));
                fr1Magni.setText("Magnitude: " + getMagni(9, 1));
                fr1Depth.setText("Depth: " + getDepth(9, 1) + "km");
                fr1Cord.setText("Co-ords: Lat: " + getLat(9, 1) + "  Long: " + getLong(9, 1));
                fr1Magni.setTextColor(magniColour(getMagni(9, 1)));

            }

        }

        if (v == fr2Button) {

            if (page == 0) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(2).substring(11, alist.get(2).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(2).substring(11, alist.get(2).length() - 91));
                }

                fr2Loc.setText("Location: " + getLoc(0, 2));
                fr2Date.setText("Date: " + getDate(0, 2));
                fr2Magni.setText("Magnitude: " + getMagni(0, 2));
                fr2Depth.setText("Depth: " + getDepth(0, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(0, 2) + "  Long: " + getLong(0, 2));
                fr2Magni.setTextColor(magniColour(getMagni(0, 2)));

            }
            if (page == 1) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(12).substring(11, alist.get(12).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(12).substring(11, alist.get(12).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(1, 2));
                fr2Date.setText("Date: " + getDate(1, 2));
                fr2Magni.setText("Magnitude: " + getMagni(1, 2));
                fr2Depth.setText("Depth: " + getDepth(1, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(1, 2) + "  Long: " + getLong(1, 2));
                fr2Magni.setTextColor(magniColour(getMagni(1, 2)));

            }
            if (page == 2) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(22).substring(11, alist.get(22).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(22).substring(11, alist.get(22).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(2, 2));
                fr2Date.setText("Date: " + getDate(2, 2));
                fr2Magni.setText("Magnitude: " + getMagni(2, 2));
                fr2Depth.setText("Depth: " + getDepth(2, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(2, 2) + "  Long: " + getLong(2, 2));
                fr2Magni.setTextColor(magniColour(getMagni(2, 2)));
            }
            if (page == 3) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(32).substring(11, alist.get(32).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(32).substring(11, alist.get(32).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(3, 2));
                fr2Date.setText("Date: " + getDate(3, 2));
                fr2Magni.setText("Magnitude: " + getMagni(3, 2));
                fr2Depth.setText("Depth: " + getDepth(3, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(3, 2) + "  Long: " + getLong(3, 2));
                fr2Magni.setTextColor(magniColour(getMagni(3, 2)));

            }
            if (page == 4) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(42).substring(11, alist.get(42).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(42).substring(11, alist.get(42).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(4, 2));
                fr2Date.setText("Date: " + getDate(4, 2));
                fr2Magni.setText("Magnitude: " + getMagni(4, 2));
                fr2Depth.setText("Depth: " + getDepth(4, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(4, 2) + "  Long: " + getLong(4, 2));
                fr2Magni.setTextColor(magniColour(getMagni(4, 2)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(52).substring(11, alist.get(52).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(52).substring(11, alist.get(52).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(5, 2));
                fr2Date.setText("Date: " + getDate(5, 2));
                fr2Magni.setText("Magnitude: " + getMagni(5, 2));
                fr2Depth.setText("Depth: " + getDepth(5, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(5, 2) + "  Long: " + getLong(5, 2));
                fr2Magni.setTextColor(magniColour(getMagni(5, 2)));

            }
            if (page == 6) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(62).substring(11, alist.get(62).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(62).substring(11, alist.get(62).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(6, 2));
                fr2Date.setText("Date: " + getDate(6, 2));
                fr2Magni.setText("Magnitude: " + getMagni(6, 2));
                fr2Depth.setText("Depth: " + getDepth(6, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(6, 2) + "  Long: " + getLong(6, 2));
                fr2Magni.setTextColor(magniColour(getMagni(6, 2)));

            }
            if (page == 7) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(72).substring(11, alist.get(72).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(72).substring(11, alist.get(72).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(7, 2));
                fr2Date.setText("Date: " + getDate(7, 2));
                fr2Magni.setText("Magnitude: " + getMagni(7, 2));
                fr2Depth.setText("Depth: " + getDepth(7, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(7, 2) + "  Long: " + getLong(7, 2));
                fr2Magni.setTextColor(magniColour(getMagni(7, 2)));

            }
            if (page == 8) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(82).substring(11, alist.get(82).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(82).substring(11, alist.get(82).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(8, 2));
                fr2Date.setText("Date: " + getDate(8, 2));
                fr2Magni.setText("Magnitude: " + getMagni(8, 2));
                fr2Depth.setText("Depth: " + getDepth(8, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(8, 2) + "  Long: " + getLong(8, 2));
                fr2Magni.setTextColor(magniColour(getMagni(8, 2)));

            }
            if (page == 9) {
                if (fr2Button.isChecked()) {
                    fr2Loc.setVisibility(View.VISIBLE);
                    fr2Date.setVisibility(View.VISIBLE);
                    fr2Cord.setVisibility(View.VISIBLE);
                    fr2Magni.setVisibility(View.VISIBLE);
                    fr2Depth.setVisibility(View.VISIBLE);
                    fr2Button.setText("Earthquake at: " + alist.get(92).substring(11, alist.get(92).length() - 91));

                } else {
                    fr2Loc.setVisibility(View.GONE);
                    fr2Date.setVisibility(View.GONE);
                    fr2Cord.setVisibility(View.GONE);
                    fr2Magni.setVisibility(View.GONE);
                    fr2Depth.setVisibility(View.GONE);
                    fr2Button.setText("Earthquake at: " + alist.get(92).substring(11, alist.get(92).length() - 91));
                }


                fr2Loc.setText("Location: " + getLoc(9, 2));
                fr2Date.setText("Date: " + getDate(9, 2));
                fr2Magni.setText("Magnitude: " + getMagni(9, 2));
                fr2Depth.setText("Depth: " + getDepth(9, 2) + "km");
                fr2Cord.setText("Co-ords: Lat: " + getLat(9, 2) + "  Long: " + getLong(9, 2));
                fr2Magni.setTextColor(magniColour(getMagni(9, 2)));

            }

        }
        if (v == fr3Button) {

            if (page == 0) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(3).substring(11, alist.get(3).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(3).substring(11, alist.get(3).length() - 91));
                }

                fr3Loc.setText("Location: " + getLoc(0, 3));
                fr3Date.setText("Date: " + getDate(0, 3));
                fr3Magni.setText("Magnitude: " + getMagni(0, 3));
                fr3Depth.setText("Depth: " + getDepth(0, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(0, 3) + "  Long: " + getLong(0, 3));
                fr3Magni.setTextColor(magniColour(getMagni(0, 3)));

            }
            if (page == 1) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(13).substring(11, alist.get(13).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(13).substring(11, alist.get(13).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(1, 3));
                fr3Date.setText("Date: " + getDate(1, 3));
                fr3Magni.setText("Magnitude: " + getMagni(1, 3));
                fr3Depth.setText("Depth: " + getDepth(1, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(1, 3) + "  Long: " + getLong(1, 3));
                fr3Magni.setTextColor(magniColour(getMagni(1, 3)));

            }
            if (page == 2) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(23).substring(11, alist.get(23).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(23).substring(11, alist.get(23).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(2, 3));
                fr3Date.setText("Date: " + getDate(2, 3));
                fr3Magni.setText("Magnitude: " + getMagni(2, 3));
                fr3Depth.setText("Depth: " + getDepth(2, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(2, 3) + "  Long: " + getLong(2, 3));
                fr3Magni.setTextColor(magniColour(getMagni(2, 3)));
            }
            if (page == 3) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(33).substring(11, alist.get(33).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(33).substring(11, alist.get(33).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(3, 3));
                fr3Date.setText("Date: " + getDate(3, 3));
                fr3Magni.setText("Magnitude: " + getMagni(3, 3));
                fr3Depth.setText("Depth: " + getDepth(3, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(3, 3) + "  Long: " + getLong(3, 3));
                fr3Magni.setTextColor(magniColour(getMagni(3, 3)));

            }
            if (page == 4) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(43).substring(11, alist.get(43).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(43).substring(11, alist.get(43).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(4, 3));
                fr3Date.setText("Date: " + getDate(4, 3));
                fr3Magni.setText("Magnitude: " + getMagni(4, 3));
                fr3Depth.setText("Depth: " + getDepth(4, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(4, 3) + "  Long: " + getLong(4, 3));
                fr3Magni.setTextColor(magniColour(getMagni(4, 3)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(53).substring(11, alist.get(53).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(53).substring(11, alist.get(53).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(5, 3));
                fr3Date.setText("Date: " + getDate(5, 3));
                fr3Magni.setText("Magnitude: " + getMagni(5, 3));
                fr3Depth.setText("Depth: " + getDepth(5, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(5, 3) + "  Long: " + getLong(5, 3));
                fr3Magni.setTextColor(magniColour(getMagni(5, 3)));

            }
            if (page == 6) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(63).substring(11, alist.get(63).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(63).substring(11, alist.get(63).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(6, 3));
                fr3Date.setText("Date: " + getDate(6, 3));
                fr3Magni.setText("Magnitude: " + getMagni(6, 3));
                fr3Depth.setText("Depth: " + getDepth(6, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(6, 3) + "  Long: " + getLong(6, 3));
                fr3Magni.setTextColor(magniColour(getMagni(6, 3)));

            }
            if (page == 7) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(73).substring(11, alist.get(73).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(73).substring(11, alist.get(73).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(7, 3));
                fr3Date.setText("Date: " + getDate(7, 3));
                fr3Magni.setText("Magnitude: " + getMagni(7, 3));
                fr3Depth.setText("Depth: " + getDepth(7, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(7, 3) + "  Long: " + getLong(7, 3));
                fr3Magni.setTextColor(magniColour(getMagni(7, 3)));

            }
            if (page == 8) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(83).substring(11, alist.get(83).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(83).substring(11, alist.get(83).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(8, 3));
                fr3Date.setText("Date: " + getDate(8, 3));
                fr3Magni.setText("Magnitude: " + getMagni(8, 3));
                fr3Depth.setText("Depth: " + getDepth(8, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(8, 3) + "  Long: " + getLong(8, 3));
                fr3Magni.setTextColor(magniColour(getMagni(8, 3)));

            }
            if (page == 9) {
                if (fr3Button.isChecked()) {
                    fr3Loc.setVisibility(View.VISIBLE);
                    fr3Date.setVisibility(View.VISIBLE);
                    fr3Cord.setVisibility(View.VISIBLE);
                    fr3Magni.setVisibility(View.VISIBLE);
                    fr3Depth.setVisibility(View.VISIBLE);
                    fr3Button.setText("Earthquake at: " + alist.get(93).substring(11, alist.get(93).length() - 91));

                } else {
                    fr3Loc.setVisibility(View.GONE);
                    fr3Date.setVisibility(View.GONE);
                    fr3Cord.setVisibility(View.GONE);
                    fr3Magni.setVisibility(View.GONE);
                    fr3Depth.setVisibility(View.GONE);
                    fr3Button.setText("Earthquake at: " + alist.get(93).substring(11, alist.get(93).length() - 91));
                }


                fr3Loc.setText("Location: " + getLoc(9, 3));
                fr3Date.setText("Date: " + getDate(9, 3));
                fr3Magni.setText("Magnitude: " + getMagni(9, 3));
                fr3Depth.setText("Depth: " + getDepth(9, 3) + "km");
                fr3Cord.setText("Co-ords: Lat: " + getLat(9, 3) + "  Long: " + getLong(9, 3));
                fr3Magni.setTextColor(magniColour(getMagni(9, 3)));

            }

        }
        if (v == fr4Button) {

            if (page == 0) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(4).substring(11, alist.get(4).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(4).substring(11, alist.get(4).length() - 91));
                }

                fr4Loc.setText("Location: " + getLoc(0, 4));
                fr4Date.setText("Date: " + getDate(0, 4));
                fr4Magni.setText("Magnitude: " + getMagni(0, 4));
                fr4Depth.setText("Depth: " + getDepth(0, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(0, 4) + "  Long: " + getLong(0, 4));
                fr4Magni.setTextColor(magniColour(getMagni(0, 4)));

            }
            if (page == 1) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(14).substring(11, alist.get(14).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(14).substring(11, alist.get(14).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(1, 4));
                fr4Date.setText("Date: " + getDate(1, 4));
                fr4Magni.setText("Magnitude: " + getMagni(1, 4));
                fr4Depth.setText("Depth: " + getDepth(1, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(1, 4) + "  Long: " + getLong(1, 4));
                fr4Magni.setTextColor(magniColour(getMagni(1, 4)));

            }
            if (page == 2) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(24).substring(11, alist.get(24).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(24).substring(11, alist.get(24).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(2, 4));
                fr4Date.setText("Date: " + getDate(2, 4));
                fr4Magni.setText("Magnitude: " + getMagni(2, 4));
                fr4Depth.setText("Depth: " + getDepth(2, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(2, 4) + "  Long: " + getLong(2, 4));
                fr4Magni.setTextColor(magniColour(getMagni(2, 4)));
            }
            if (page == 3) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(34).substring(11, alist.get(34).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(34).substring(11, alist.get(34).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(3, 4));
                fr4Date.setText("Date: " + getDate(3, 4));
                fr4Magni.setText("Magnitude: " + getMagni(3, 4));
                fr4Depth.setText("Depth: " + getDepth(3, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(3, 4) + "  Long: " + getLong(3, 4));
                fr4Magni.setTextColor(magniColour(getMagni(3, 4)));

            }
            if (page == 4) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(44).substring(11, alist.get(44).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(44).substring(11, alist.get(44).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(4, 4));
                fr4Date.setText("Date: " + getDate(4, 4));
                fr4Magni.setText("Magnitude: " + getMagni(4, 4));
                fr4Depth.setText("Depth: " + getDepth(4, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(4, 4) + "  Long: " + getLong(4, 4));
                fr4Magni.setTextColor(magniColour(getMagni(4, 4)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(54).substring(11, alist.get(54).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(54).substring(11, alist.get(54).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(5, 4));
                fr4Date.setText("Date: " + getDate(5, 4));
                fr4Magni.setText("Magnitude: " + getMagni(5, 4));
                fr4Depth.setText("Depth: " + getDepth(5, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(5, 4) + "  Long: " + getLong(5, 4));
                fr4Magni.setTextColor(magniColour(getMagni(5, 4)));

            }
            if (page == 6) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(64).substring(11, alist.get(64).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(64).substring(11, alist.get(64).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(6, 4));
                fr4Date.setText("Date: " + getDate(6, 4));
                fr4Magni.setText("Magnitude: " + getMagni(6, 4));
                fr4Depth.setText("Depth: " + getDepth(6, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(6, 4) + "  Long: " + getLong(6, 4));
                fr4Magni.setTextColor(magniColour(getMagni(6, 4)));

            }
            if (page == 7) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(74).substring(11, alist.get(74).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(74).substring(11, alist.get(74).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(7, 4));
                fr4Date.setText("Date: " + getDate(7, 4));
                fr4Magni.setText("Magnitude: " + getMagni(7, 4));
                fr4Depth.setText("Depth: " + getDepth(7, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(7, 4) + "  Long: " + getLong(7, 4));
                fr4Magni.setTextColor(magniColour(getMagni(7, 4)));

            }
            if (page == 8) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(84).substring(11, alist.get(84).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(84).substring(11, alist.get(84).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(8, 4));
                fr4Date.setText("Date: " + getDate(8, 4));
                fr4Magni.setText("Magnitude: " + getMagni(8, 4));
                fr4Depth.setText("Depth: " + getDepth(8, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(8, 4) + "  Long: " + getLong(8, 4));
                fr4Magni.setTextColor(magniColour(getMagni(8, 4)));

            }
            if (page == 9) {
                if (fr4Button.isChecked()) {
                    fr4Loc.setVisibility(View.VISIBLE);
                    fr4Date.setVisibility(View.VISIBLE);
                    fr4Cord.setVisibility(View.VISIBLE);
                    fr4Magni.setVisibility(View.VISIBLE);
                    fr4Depth.setVisibility(View.VISIBLE);
                    fr4Button.setText("Earthquake at: " + alist.get(94).substring(11, alist.get(94).length() - 91));

                } else {
                    fr4Loc.setVisibility(View.GONE);
                    fr4Date.setVisibility(View.GONE);
                    fr4Cord.setVisibility(View.GONE);
                    fr4Magni.setVisibility(View.GONE);
                    fr4Depth.setVisibility(View.GONE);
                    fr4Button.setText("Earthquake at: " + alist.get(94).substring(11, alist.get(94).length() - 91));
                }


                fr4Loc.setText("Location: " + getLoc(9, 4));
                fr4Date.setText("Date: " + getDate(9, 4));
                fr4Magni.setText("Magnitude: " + getMagni(9, 4));
                fr4Depth.setText("Depth: " + getDepth(9, 4) + "km");
                fr4Cord.setText("Co-ords: Lat: " + getLat(9, 4) + "  Long: " + getLong(9, 4));
                fr4Magni.setTextColor(magniColour(getMagni(9, 4)));

            }

        }
        if (v == fr5Button) {

            if (page == 0) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(5).substring(11, alist.get(5).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(5).substring(11, alist.get(5).length() - 91));
                }

                fr5Loc.setText("Location: " + getLoc(0, 5));
                fr5Date.setText("Date: " + getDate(0, 5));
                fr5Magni.setText("Magnitude: " + getMagni(0, 5));
                fr5Depth.setText("Depth: " + getDepth(0, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(0, 5) + "  Long: " + getLong(0, 5));
                fr5Magni.setTextColor(magniColour(getMagni(0, 5)));

            }
            if (page == 1) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(15).substring(11, alist.get(15).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(15).substring(11, alist.get(15).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(1, 5));
                fr5Date.setText("Date: " + getDate(1, 5));
                fr5Magni.setText("Magnitude: " + getMagni(1, 5));
                fr5Depth.setText("Depth: " + getDepth(1, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(1, 5) + "  Long: " + getLong(1, 5));
                fr5Magni.setTextColor(magniColour(getMagni(1, 5)));

            }
            if (page == 2) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(25).substring(11, alist.get(25).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(25).substring(11, alist.get(25).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(2, 5));
                fr5Date.setText("Date: " + getDate(2, 5));
                fr5Magni.setText("Magnitude: " + getMagni(2, 5));
                fr5Depth.setText("Depth: " + getDepth(2, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(2, 5) + "  Long: " + getLong(2, 5));
                fr5Magni.setTextColor(magniColour(getMagni(2, 5)));
            }
            if (page == 3) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(35).substring(11, alist.get(35).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(35).substring(11, alist.get(35).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(3, 5));
                fr5Date.setText("Date: " + getDate(3, 5));
                fr5Magni.setText("Magnitude: " + getMagni(3, 5));
                fr5Depth.setText("Depth: " + getDepth(3, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(3, 5) + "  Long: " + getLong(3, 5));
                fr5Magni.setTextColor(magniColour(getMagni(3, 5)));

            }
            if (page == 4) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(45).substring(11, alist.get(45).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(45).substring(11, alist.get(45).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(4, 5));
                fr5Date.setText("Date: " + getDate(4, 5));
                fr5Magni.setText("Magnitude: " + getMagni(4, 5));
                fr5Depth.setText("Depth: " + getDepth(4, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(4, 5) + "  Long: " + getLong(4, 5));
                fr5Magni.setTextColor(magniColour(getMagni(4, 5)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(55).substring(11, alist.get(55).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(55).substring(11, alist.get(55).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(5, 5));
                fr5Date.setText("Date: " + getDate(5, 5));
                fr5Magni.setText("Magnitude: " + getMagni(5, 5));
                fr5Depth.setText("Depth: " + getDepth(5, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(5, 5) + "  Long: " + getLong(5, 5));
                fr5Magni.setTextColor(magniColour(getMagni(5, 5)));

            }
            if (page == 6) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(65).substring(11, alist.get(65).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(65).substring(11, alist.get(65).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(6, 5));
                fr5Date.setText("Date: " + getDate(6, 5));
                fr5Magni.setText("Magnitude: " + getMagni(6, 5));
                fr5Depth.setText("Depth: " + getDepth(6, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(6, 5) + "  Long: " + getLong(6, 5));
                fr5Magni.setTextColor(magniColour(getMagni(6, 5)));

            }
            if (page == 7) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(75).substring(11, alist.get(75).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(75).substring(11, alist.get(75).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(7, 5));
                fr5Date.setText("Date: " + getDate(7, 5));
                fr5Magni.setText("Magnitude: " + getMagni(7, 5));
                fr5Depth.setText("Depth: " + getDepth(7, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(7, 5) + "  Long: " + getLong(7, 5));
                fr5Magni.setTextColor(magniColour(getMagni(7, 5)));

            }
            if (page == 8) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(85).substring(11, alist.get(85).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(85).substring(11, alist.get(85).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(8, 5));
                fr5Date.setText("Date: " + getDate(8, 5));
                fr5Magni.setText("Magnitude: " + getMagni(8, 5));
                fr5Depth.setText("Depth: " + getDepth(8, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(8, 5) + "  Long: " + getLong(8, 5));
                fr5Magni.setTextColor(magniColour(getMagni(8, 5)));

            }
            if (page == 9) {
                if (fr5Button.isChecked()) {
                    fr5Loc.setVisibility(View.VISIBLE);
                    fr5Date.setVisibility(View.VISIBLE);
                    fr5Cord.setVisibility(View.VISIBLE);
                    fr5Magni.setVisibility(View.VISIBLE);
                    fr5Depth.setVisibility(View.VISIBLE);
                    fr5Button.setText("Earthquake at: " + alist.get(95).substring(11, alist.get(95).length() - 91));

                } else {
                    fr5Loc.setVisibility(View.GONE);
                    fr5Date.setVisibility(View.GONE);
                    fr5Cord.setVisibility(View.GONE);
                    fr5Magni.setVisibility(View.GONE);
                    fr5Depth.setVisibility(View.GONE);
                    fr5Button.setText("Earthquake at: " + alist.get(95).substring(11, alist.get(95).length() - 91));
                }


                fr5Loc.setText("Location: " + getLoc(9, 5));
                fr5Date.setText("Date: " + getDate(9, 5));
                fr5Magni.setText("Magnitude: " + getMagni(9, 5));
                fr5Depth.setText("Depth: " + getDepth(9, 5) + "km");
                fr5Cord.setText("Co-ords: Lat: " + getLat(9, 5) + "  Long: " + getLong(9, 5));
                fr5Magni.setTextColor(magniColour(getMagni(9, 5)));

            }

        }
        if (v == fr6Button) {

            if (page == 0) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(6).substring(11, alist.get(6).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(6).substring(11, alist.get(6).length() - 91));
                }

                fr6Loc.setText("Location: " + getLoc(0, 6));
                fr6Date.setText("Date: " + getDate(0, 6));
                fr6Magni.setText("Magnitude: " + getMagni(0, 6));
                fr6Depth.setText("Depth: " + getDepth(0, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(0, 6) + "  Long: " + getLong(0, 6));
                fr6Magni.setTextColor(magniColour(getMagni(0, 6)));

            }
            if (page == 1) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(16).substring(11, alist.get(16).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(16).substring(11, alist.get(16).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(1, 6));
                fr6Date.setText("Date: " + getDate(1, 6));
                fr6Magni.setText("Magnitude: " + getMagni(1, 6));
                fr6Depth.setText("Depth: " + getDepth(1, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(1, 6) + "  Long: " + getLong(1, 6));
                fr6Magni.setTextColor(magniColour(getMagni(1, 6)));

            }
            if (page == 2) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(26).substring(11, alist.get(26).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(26).substring(11, alist.get(26).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(2, 6));
                fr6Date.setText("Date: " + getDate(2, 6));
                fr6Magni.setText("Magnitude: " + getMagni(2, 6));
                fr6Depth.setText("Depth: " + getDepth(2, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(2, 6) + "  Long: " + getLong(2, 6));
                fr6Magni.setTextColor(magniColour(getMagni(2, 6)));
            }
            if (page == 3) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(36).substring(11, alist.get(36).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(36).substring(11, alist.get(36).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(3, 6));
                fr6Date.setText("Date: " + getDate(3, 6));
                fr6Magni.setText("Magnitude: " + getMagni(3, 6));
                fr6Depth.setText("Depth: " + getDepth(3, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(3, 6) + "  Long: " + getLong(3, 6));
                fr6Magni.setTextColor(magniColour(getMagni(3, 6)));

            }
            if (page == 4) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(46).substring(11, alist.get(46).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(46).substring(11, alist.get(46).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(4, 6));
                fr6Date.setText("Date: " + getDate(4, 6));
                fr6Magni.setText("Magnitude: " + getMagni(4, 6));
                fr6Depth.setText("Depth: " + getDepth(4, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(4, 6) + "  Long: " + getLong(4, 6));
                fr6Magni.setTextColor(magniColour(getMagni(4, 6)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(56).substring(11, alist.get(56).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(56).substring(11, alist.get(56).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(5, 6));
                fr6Date.setText("Date: " + getDate(5, 6));
                fr6Magni.setText("Magnitude: " + getMagni(5, 6));
                fr6Depth.setText("Depth: " + getDepth(5, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(5, 6) + "  Long: " + getLong(5, 6));
                fr6Magni.setTextColor(magniColour(getMagni(5, 6)));

            }
            if (page == 6) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(66).substring(11, alist.get(66).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(66).substring(11, alist.get(66).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(6, 6));
                fr6Date.setText("Date: " + getDate(6, 6));
                fr6Magni.setText("Magnitude: " + getMagni(6, 6));
                fr6Depth.setText("Depth: " + getDepth(6, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(6, 6) + "  Long: " + getLong(6, 6));
                fr6Magni.setTextColor(magniColour(getMagni(6, 6)));

            }
            if (page == 7) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(76).substring(11, alist.get(76).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(76).substring(11, alist.get(76).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(7, 6));
                fr6Date.setText("Date: " + getDate(7, 6));
                fr6Magni.setText("Magnitude: " + getMagni(7, 6));
                fr6Depth.setText("Depth: " + getDepth(7, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(7, 6) + "  Long: " + getLong(7, 6));
                fr6Magni.setTextColor(magniColour(getMagni(7, 6)));

            }
            if (page == 8) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(86).substring(11, alist.get(86).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(86).substring(11, alist.get(86).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(8, 6));
                fr6Date.setText("Date: " + getDate(8, 6));
                fr6Magni.setText("Magnitude: " + getMagni(8, 6));
                fr6Depth.setText("Depth: " + getDepth(8, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(8, 6) + "  Long: " + getLong(8, 6));
                fr6Magni.setTextColor(magniColour(getMagni(8, 6)));

            }
            if (page == 9) {
                if (fr6Button.isChecked()) {
                    fr6Loc.setVisibility(View.VISIBLE);
                    fr6Date.setVisibility(View.VISIBLE);
                    fr6Cord.setVisibility(View.VISIBLE);
                    fr6Magni.setVisibility(View.VISIBLE);
                    fr6Depth.setVisibility(View.VISIBLE);
                    fr6Button.setText("Earthquake at: " + alist.get(96).substring(11, alist.get(96).length() - 91));

                } else {
                    fr6Loc.setVisibility(View.GONE);
                    fr6Date.setVisibility(View.GONE);
                    fr6Cord.setVisibility(View.GONE);
                    fr6Magni.setVisibility(View.GONE);
                    fr6Depth.setVisibility(View.GONE);
                    fr6Button.setText("Earthquake at: " + alist.get(96).substring(11, alist.get(96).length() - 91));
                }


                fr6Loc.setText("Location: " + getLoc(9, 6));
                fr6Date.setText("Date: " + getDate(9, 6));
                fr6Magni.setText("Magnitude: " + getMagni(9, 6));
                fr6Depth.setText("Depth: " + getDepth(9, 6) + "km");
                fr6Cord.setText("Co-ords: Lat: " + getLat(9, 6) + "  Long: " + getLong(9, 6));
                fr6Magni.setTextColor(magniColour(getMagni(9, 6)));

            }

        }
        if (v == fr7Button) {

            if (page == 0) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(7).substring(11, alist.get(7).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(7).substring(11, alist.get(7).length() - 91));
                }

                fr7Loc.setText("Location: " + getLoc(0, 7));
                fr7Date.setText("Date: " + getDate(0, 7));
                fr7Magni.setText("Magnitude: " + getMagni(0, 7));
                fr7Depth.setText("Depth: " + getDepth(0, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(0, 7) + "  Long: " + getLong(0, 7));
                fr7Magni.setTextColor(magniColour(getMagni(0, 7)));

            }
            if (page == 1) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(17).substring(11, alist.get(17).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(17).substring(11, alist.get(17).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(1, 7));
                fr7Date.setText("Date: " + getDate(1, 7));
                fr7Magni.setText("Magnitude: " + getMagni(1, 7));
                fr7Depth.setText("Depth: " + getDepth(1, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(1, 7) + "  Long: " + getLong(1, 7));
                fr7Magni.setTextColor(magniColour(getMagni(1, 7)));

            }
            if (page == 2) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(27).substring(11, alist.get(27).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(27).substring(11, alist.get(27).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(2, 7));
                fr7Date.setText("Date: " + getDate(2, 7));
                fr7Magni.setText("Magnitude: " + getMagni(2, 7));
                fr7Depth.setText("Depth: " + getDepth(2, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(2, 7) + "  Long: " + getLong(2, 7));
                fr7Magni.setTextColor(magniColour(getMagni(2, 7)));
            }
            if (page == 3) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(37).substring(11, alist.get(37).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(37).substring(11, alist.get(37).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(3, 7));
                fr7Date.setText("Date: " + getDate(3, 7));
                fr7Magni.setText("Magnitude: " + getMagni(3, 7));
                fr7Depth.setText("Depth: " + getDepth(3, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(3, 7) + "  Long: " + getLong(3, 7));
                fr7Magni.setTextColor(magniColour(getMagni(3, 7)));

            }
            if (page == 4) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(47).substring(11, alist.get(47).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(47).substring(11, alist.get(47).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(4, 7));
                fr7Date.setText("Date: " + getDate(4, 7));
                fr7Magni.setText("Magnitude: " + getMagni(4, 7));
                fr7Depth.setText("Depth: " + getDepth(4, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(4, 7) + "  Long: " + getLong(4, 7));
                fr7Magni.setTextColor(magniColour(getMagni(4, 7)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(57).substring(11, alist.get(57).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(57).substring(11, alist.get(57).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(5, 7));
                fr7Date.setText("Date: " + getDate(5, 7));
                fr7Magni.setText("Magnitude: " + getMagni(5, 7));
                fr7Depth.setText("Depth: " + getDepth(5, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(5, 7) + "  Long: " + getLong(5, 7));
                fr7Magni.setTextColor(magniColour(getMagni(5, 7)));

            }
            if (page == 6) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(67).substring(11, alist.get(67).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(67).substring(11, alist.get(67).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(6, 7));
                fr7Date.setText("Date: " + getDate(6, 7));
                fr7Magni.setText("Magnitude: " + getMagni(6, 7));
                fr7Depth.setText("Depth: " + getDepth(6, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(6, 7) + "  Long: " + getLong(6, 7));
                fr7Magni.setTextColor(magniColour(getMagni(6, 7)));

            }
            if (page == 7) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(77).substring(11, alist.get(77).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(77).substring(11, alist.get(77).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(7, 7));
                fr7Date.setText("Date: " + getDate(7, 7));
                fr7Magni.setText("Magnitude: " + getMagni(7, 7));
                fr7Depth.setText("Depth: " + getDepth(7, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(7, 7) + "  Long: " + getLong(7, 7));
                fr7Magni.setTextColor(magniColour(getMagni(7, 7)));

            }
            if (page == 8) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(87).substring(11, alist.get(87).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(87).substring(11, alist.get(87).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(8, 7));
                fr7Date.setText("Date: " + getDate(8, 7));
                fr7Magni.setText("Magnitude: " + getMagni(8, 7));
                fr7Depth.setText("Depth: " + getDepth(8, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(8, 7) + "  Long: " + getLong(8, 7));
                fr7Magni.setTextColor(magniColour(getMagni(8, 7)));

            }
            if (page == 9) {
                if (fr7Button.isChecked()) {
                    fr7Loc.setVisibility(View.VISIBLE);
                    fr7Date.setVisibility(View.VISIBLE);
                    fr7Cord.setVisibility(View.VISIBLE);
                    fr7Magni.setVisibility(View.VISIBLE);
                    fr7Depth.setVisibility(View.VISIBLE);
                    fr7Button.setText("Earthquake at: " + alist.get(97).substring(11, alist.get(97).length() - 91));

                } else {
                    fr7Loc.setVisibility(View.GONE);
                    fr7Date.setVisibility(View.GONE);
                    fr7Cord.setVisibility(View.GONE);
                    fr7Magni.setVisibility(View.GONE);
                    fr7Depth.setVisibility(View.GONE);
                    fr7Button.setText("Earthquake at: " + alist.get(97).substring(11, alist.get(97).length() - 91));
                }


                fr7Loc.setText("Location: " + getLoc(9, 7));
                fr7Date.setText("Date: " + getDate(9, 7));
                fr7Magni.setText("Magnitude: " + getMagni(9, 7));
                fr7Depth.setText("Depth: " + getDepth(9, 7) + "km");
                fr7Cord.setText("Co-ords: Lat: " + getLat(9, 7) + "  Long: " + getLong(9, 7));
                fr7Magni.setTextColor(magniColour(getMagni(9, 7)));

            }

        }
        if (v == fr8Button) {

            if (page == 0) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(8).substring(11, alist.get(8).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(8).substring(11, alist.get(8).length() - 91));
                }

                fr8Loc.setText("Location: " + getLoc(0, 8));
                fr8Date.setText("Date: " + getDate(0, 8));
                fr8Magni.setText("Magnitude: " + getMagni(0, 8));
                fr8Depth.setText("Depth: " + getDepth(0, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(0, 8) + "  Long: " + getLong(0, 8));
                fr8Magni.setTextColor(magniColour(getMagni(0, 8)));

            }
            if (page == 1) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(18).substring(11, alist.get(18).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(18).substring(11, alist.get(18).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(1, 8));
                fr8Date.setText("Date: " + getDate(1, 8));
                fr8Magni.setText("Magnitude: " + getMagni(1, 8));
                fr8Depth.setText("Depth: " + getDepth(1, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(1, 8) + "  Long: " + getLong(1, 8));
                fr8Magni.setTextColor(magniColour(getMagni(1, 8)));

            }
            if (page == 2) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(28).substring(11, alist.get(28).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(28).substring(11, alist.get(28).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(2, 8));
                fr8Date.setText("Date: " + getDate(2, 8));
                fr8Magni.setText("Magnitude: " + getMagni(2, 8));
                fr8Depth.setText("Depth: " + getDepth(2, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(2, 8) + "  Long: " + getLong(2, 8));
                fr8Magni.setTextColor(magniColour(getMagni(2, 8)));
            }
            if (page == 3) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(38).substring(11, alist.get(38).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(38).substring(11, alist.get(38).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(3, 8));
                fr8Date.setText("Date: " + getDate(3, 8));
                fr8Magni.setText("Magnitude: " + getMagni(3, 8));
                fr8Depth.setText("Depth: " + getDepth(3, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(3, 8) + "  Long: " + getLong(3, 8));
                fr8Magni.setTextColor(magniColour(getMagni(3, 8)));

            }
            if (page == 4) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(48).substring(11, alist.get(48).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(48).substring(11, alist.get(48).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(4, 8));
                fr8Date.setText("Date: " + getDate(4, 8));
                fr8Magni.setText("Magnitude: " + getMagni(4, 8));
                fr8Depth.setText("Depth: " + getDepth(4, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(4, 8) + "  Long: " + getLong(4, 8));
                fr8Magni.setTextColor(magniColour(getMagni(4, 8)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(58).substring(11, alist.get(58).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(58).substring(11, alist.get(58).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(5, 8));
                fr8Date.setText("Date: " + getDate(5, 8));
                fr8Magni.setText("Magnitude: " + getMagni(5, 8));
                fr8Depth.setText("Depth: " + getDepth(5, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(5, 8) + "  Long: " + getLong(5, 8));
                fr8Magni.setTextColor(magniColour(getMagni(5, 8)));

            }
            if (page == 6) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(68).substring(11, alist.get(68).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(68).substring(11, alist.get(68).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(6, 8));
                fr8Date.setText("Date: " + getDate(6, 8));
                fr8Magni.setText("Magnitude: " + getMagni(6, 8));
                fr8Depth.setText("Depth: " + getDepth(6, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(6, 8) + "  Long: " + getLong(6, 8));
                fr8Magni.setTextColor(magniColour(getMagni(6, 8)));

            }
            if (page == 7) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(78).substring(11, alist.get(78).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(78).substring(11, alist.get(78).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(7, 8));
                fr8Date.setText("Date: " + getDate(7, 8));
                fr8Magni.setText("Magnitude: " + getMagni(7, 8));
                fr8Depth.setText("Depth: " + getDepth(7, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(7, 8) + "  Long: " + getLong(7, 8));
                fr8Magni.setTextColor(magniColour(getMagni(7, 8)));

            }
            if (page == 8) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(88).substring(11, alist.get(88).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(88).substring(11, alist.get(88).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(8, 8));
                fr8Date.setText("Date: " + getDate(8, 8));
                fr8Magni.setText("Magnitude: " + getMagni(8, 8));
                fr8Depth.setText("Depth: " + getDepth(8, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(8, 8) + "  Long: " + getLong(8, 8));
                fr8Magni.setTextColor(magniColour(getMagni(8, 8)));

            }
            if (page == 9) {
                if (fr8Button.isChecked()) {
                    fr8Loc.setVisibility(View.VISIBLE);
                    fr8Date.setVisibility(View.VISIBLE);
                    fr8Cord.setVisibility(View.VISIBLE);
                    fr8Magni.setVisibility(View.VISIBLE);
                    fr8Depth.setVisibility(View.VISIBLE);
                    fr8Button.setText("Earthquake at: " + alist.get(98).substring(11, alist.get(98).length() - 91));

                } else {
                    fr8Loc.setVisibility(View.GONE);
                    fr8Date.setVisibility(View.GONE);
                    fr8Cord.setVisibility(View.GONE);
                    fr8Magni.setVisibility(View.GONE);
                    fr8Depth.setVisibility(View.GONE);
                    fr8Button.setText("Earthquake at: " + alist.get(98).substring(11, alist.get(98).length() - 91));
                }


                fr8Loc.setText("Location: " + getLoc(9, 8));
                fr8Date.setText("Date: " + getDate(9, 8));
                fr8Magni.setText("Magnitude: " + getMagni(9, 8));
                fr8Depth.setText("Depth: " + getDepth(9, 8) + "km");
                fr8Cord.setText("Co-ords: Lat: " + getLat(9, 8) + "  Long: " + getLong(9, 8));
                fr8Magni.setTextColor(magniColour(getMagni(9, 8)));

            }

        }
        if (v == fr9Button) {

            if (page == 0) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(9).substring(11, alist.get(9).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(9).substring(11, alist.get(9).length() - 91));
                }

                fr9Loc.setText("Location: " + getLoc(0, 9));
                fr9Date.setText("Date: " + getDate(0, 9));
                fr9Magni.setText("Magnitude: " + getMagni(0, 9));
                fr9Depth.setText("Depth: " + getDepth(0, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(0, 9) + "  Long: " + getLong(0, 9));
                fr9Magni.setTextColor(magniColour(getMagni(0, 9)));

            }
            if (page == 1) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(19).substring(11, alist.get(19).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(19).substring(11, alist.get(19).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(1, 9));
                fr9Date.setText("Date: " + getDate(1, 9));
                fr9Magni.setText("Magnitude: " + getMagni(1, 9));
                fr9Depth.setText("Depth: " + getDepth(1, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(1, 9) + "  Long: " + getLong(1, 9));
                fr9Magni.setTextColor(magniColour(getMagni(1, 9)));

            }
            if (page == 2) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(29).substring(11, alist.get(29).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(29).substring(11, alist.get(29).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(2, 9));
                fr9Date.setText("Date: " + getDate(2, 9));
                fr9Magni.setText("Magnitude: " + getMagni(2, 9));
                fr9Depth.setText("Depth: " + getDepth(2, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(2, 9) + "  Long: " + getLong(2, 9));
                fr9Magni.setTextColor(magniColour(getMagni(2, 9)));
            }
            if (page == 3) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(39).substring(11, alist.get(39).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(39).substring(11, alist.get(39).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(3, 9));
                fr9Date.setText("Date: " + getDate(3, 9));
                fr9Magni.setText("Magnitude: " + getMagni(3, 9));
                fr9Depth.setText("Depth: " + getDepth(3, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(3, 9) + "  Long: " + getLong(3, 9));
                fr9Magni.setTextColor(magniColour(getMagni(3, 9)));

            }
            if (page == 4) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(49).substring(11, alist.get(49).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(49).substring(11, alist.get(49).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(4, 9));
                fr9Date.setText("Date: " + getDate(4, 9));
                fr9Magni.setText("Magnitude: " + getMagni(4, 9));
                fr9Depth.setText("Depth: " + getDepth(4, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(4, 9) + "  Long: " + getLong(4, 9));
                fr9Magni.setTextColor(magniColour(getMagni(4, 9)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(59).substring(11, alist.get(59).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(59).substring(11, alist.get(59).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(5, 9));
                fr9Date.setText("Date: " + getDate(5, 9));
                fr9Magni.setText("Magnitude: " + getMagni(5, 9));
                fr9Depth.setText("Depth: " + getDepth(5, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(5, 9) + "  Long: " + getLong(5, 9));
                fr9Magni.setTextColor(magniColour(getMagni(5, 9)));

            }
            if (page == 6) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(69).substring(11, alist.get(69).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(69).substring(11, alist.get(69).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(6, 9));
                fr9Date.setText("Date: " + getDate(6, 9));
                fr9Magni.setText("Magnitude: " + getMagni(6, 9));
                fr9Depth.setText("Depth: " + getDepth(6, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(6, 9) + "  Long: " + getLong(6, 9));
                fr9Magni.setTextColor(magniColour(getMagni(6, 9)));

            }
            if (page == 7) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(79).substring(11, alist.get(79).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(79).substring(11, alist.get(79).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(7, 9));
                fr9Date.setText("Date: " + getDate(7, 9));
                fr9Magni.setText("Magnitude: " + getMagni(7, 9));
                fr9Depth.setText("Depth: " + getDepth(7, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(7, 9) + "  Long: " + getLong(7, 9));
                fr9Magni.setTextColor(magniColour(getMagni(7, 9)));

            }
            if (page == 8) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(89).substring(11, alist.get(89).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(89).substring(11, alist.get(89).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(8, 9));
                fr9Date.setText("Date: " + getDate(8, 9));
                fr9Magni.setText("Magnitude: " + getMagni(8, 9));
                fr9Depth.setText("Depth: " + getDepth(8, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(8, 9) + "  Long: " + getLong(8, 9));
                fr9Magni.setTextColor(magniColour(getMagni(8, 9)));

            }
            if (page == 9) {
                if (fr9Button.isChecked()) {
                    fr9Loc.setVisibility(View.VISIBLE);
                    fr9Date.setVisibility(View.VISIBLE);
                    fr9Cord.setVisibility(View.VISIBLE);
                    fr9Magni.setVisibility(View.VISIBLE);
                    fr9Depth.setVisibility(View.VISIBLE);
                    fr9Button.setText("Earthquake at: " + alist.get(99).substring(11, alist.get(95).length() - 91));

                } else {
                    fr9Loc.setVisibility(View.GONE);
                    fr9Date.setVisibility(View.GONE);
                    fr9Cord.setVisibility(View.GONE);
                    fr9Magni.setVisibility(View.GONE);
                    fr9Depth.setVisibility(View.GONE);
                    fr9Button.setText("Earthquake at: " + alist.get(99).substring(11, alist.get(95).length() - 91));
                }


                fr9Loc.setText("Location: " + getLoc(9, 9));
                fr9Date.setText("Date: " + getDate(9, 9));
                fr9Magni.setText("Magnitude: " + getMagni(9, 9));
                fr9Depth.setText("Depth: " + getDepth(9, 9) + "km");
                fr9Cord.setText("Co-ords: Lat: " + getLat(9, 9) + "  Long: " + getLong(9, 9));
                fr9Magni.setTextColor(magniColour(getMagni(9, 9)));

            }

        }
        if (v == fr10Button) {

            if (page == 0) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(10).substring(11, alist.get(10).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(10).substring(11, alist.get(10).length() - 91));
                }

                fr10Loc.setText("Location: " + getLoc(0, 10));
                fr10Date.setText("Date: " + getDate(0, 10));
                fr10Magni.setText("Magnitude: " + getMagni(0, 10));
                fr10Depth.setText("Depth: " + getDepth(0, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(0, 10) + "  Long: " + getLong(0, 10));
                fr10Magni.setTextColor(magniColour(getMagni(0, 10)));

            }
            if (page == 1) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(20).substring(11, alist.get(20).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(20).substring(11, alist.get(20).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(1, 10));
                fr10Date.setText("Date: " + getDate(1, 10));
                fr10Magni.setText("Magnitude: " + getMagni(1, 10));
                fr10Depth.setText("Depth: " + getDepth(1, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(1, 10) + "  Long: " + getLong(1, 10));
                fr10Magni.setTextColor(magniColour(getMagni(1, 10)));

            }
            if (page == 2) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(30).substring(11, alist.get(30).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(30).substring(11, alist.get(30).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(2, 10));
                fr10Date.setText("Date: " + getDate(2, 10));
                fr10Magni.setText("Magnitude: " + getMagni(2, 10));
                fr10Depth.setText("Depth: " + getDepth(2, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(2, 10) + "  Long: " + getLong(2, 10));
                fr10Magni.setTextColor(magniColour(getMagni(2, 10)));
            }
            if (page == 3) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(40).substring(11, alist.get(40).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(40).substring(11, alist.get(40).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(3, 10));
                fr10Date.setText("Date: " + getDate(3, 10));
                fr10Magni.setText("Magnitude: " + getMagni(3, 10));
                fr10Depth.setText("Depth: " + getDepth(3, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(3, 10) + "  Long: " + getLong(3, 10));
                fr10Magni.setTextColor(magniColour(getMagni(3, 10)));

            }
            if (page == 4) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(50).substring(11, alist.get(50).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(50).substring(11, alist.get(50).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(4, 10));
                fr10Date.setText("Date: " + getDate(4, 10));
                fr10Magni.setText("Magnitude: " + getMagni(4, 10));
                fr10Depth.setText("Depth: " + getDepth(4, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(4, 10) + "  Long: " + getLong(4, 10));
                fr10Magni.setTextColor(magniColour(getMagni(4, 10)));

            }
            if (page == 5) {
                if (fr1Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(60).substring(11, alist.get(60).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(60).substring(11, alist.get(60).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(5, 10));
                fr10Date.setText("Date: " + getDate(5, 10));
                fr10Magni.setText("Magnitude: " + getMagni(5, 10));
                fr10Depth.setText("Depth: " + getDepth(5, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(5, 10) + "  Long: " + getLong(5, 10));
                fr10Magni.setTextColor(magniColour(getMagni(5, 10)));

            }
            if (page == 6) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(70).substring(11, alist.get(70).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(70).substring(11, alist.get(70).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(6, 10));
                fr10Date.setText("Date: " + getDate(6, 10));
                fr10Magni.setText("Magnitude: " + getMagni(6, 10));
                fr10Depth.setText("Depth: " + getDepth(6, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(6, 10) + "  Long: " + getLong(6, 10));
                fr10Magni.setTextColor(magniColour(getMagni(6, 10)));

            }
            if (page == 7) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(80).substring(11, alist.get(80).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(80).substring(11, alist.get(80).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(7, 10));
                fr10Date.setText("Date: " + getDate(7, 10));
                fr10Magni.setText("Magnitude: " + getMagni(7, 10));
                fr10Depth.setText("Depth: " + getDepth(7, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(7, 10) + "  Long: " + getLong(7, 10));
                fr10Magni.setTextColor(magniColour(getMagni(7, 10)));

            }
            if (page == 8) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(90).substring(11, alist.get(90).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(90).substring(11, alist.get(90).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(8, 10));
                fr10Date.setText("Date: " + getDate(8, 10));
                fr10Magni.setText("Magnitude: " + getMagni(8, 10));
                fr10Depth.setText("Depth: " + getDepth(8, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(8, 10) + "  Long: " + getLong(8, 10));
                fr10Magni.setTextColor(magniColour(getMagni(8, 10)));

            }
            if (page == 9) {
                if (fr10Button.isChecked()) {
                    fr10Loc.setVisibility(View.VISIBLE);
                    fr10Date.setVisibility(View.VISIBLE);
                    fr10Cord.setVisibility(View.VISIBLE);
                    fr10Magni.setVisibility(View.VISIBLE);
                    fr10Depth.setVisibility(View.VISIBLE);
                    fr10Button.setText("Earthquake at: " + alist.get(100).substring(11, alist.get(100).length() - 91));

                } else {
                    fr10Loc.setVisibility(View.GONE);
                    fr10Date.setVisibility(View.GONE);
                    fr10Cord.setVisibility(View.GONE);
                    fr10Magni.setVisibility(View.GONE);
                    fr10Depth.setVisibility(View.GONE);
                    fr10Button.setText("Earthquake at: " + alist.get(100).substring(11, alist.get(100).length() - 91));
                }


                fr10Loc.setText("Location: " + getLoc(9, 10));
                fr10Date.setText("Date: " + getDate(9, 10));
                fr10Magni.setText("Magnitude: " + getMagni(9, 10));
                fr10Depth.setText("Depth: " + getDepth(9, 10) + "km");
                fr10Cord.setText("Co-ords: Lat: " + getLat(9, 10) + "  Long: " + getLong(9, 10));
                fr10Magni.setTextColor(magniColour(getMagni(9, 10)));

            }

        }
    }
}

