/*  Starter project for Mobile Platform Development in Semester B Session 2018/2019
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 Daan Buis
// Student ID           S2025985
// Programme of Study   Computing
//

// Update the package name to include your Student Identifier
package org.me.gcu.buis_daan_s2025985;

//import android.support.v7.app.AppCompatActivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Locale;
import java.util.ListIterator;

import org.me.gcu.buis_daan_s2025985.R;

public class MainActivity extends AppCompatActivity implements OnClickListener
{
    private TextView rawDataDisplay;
    private Button startButton;
    private String result = "";
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private Fragment fr1;
    private Fragment fr;
    private static LinkedList<WidgetClass> alist = null;
    private String out = "";
    private Bundle results;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Set up the raw links to the graphical components
        startProgress();
        rawDataDisplay = (TextView)findViewById(R.id.rawDataDisplay);
        startButton = (Button)findViewById(R.id.startButton);
        startButton.setOnClickListener(this);

        // More Code goes here



    }



    public LinkedList<WidgetClass> getAlist() {
        return alist;
    }

    public void onClick(View v)
    {

        fr1 = new FragmentOne();
        fr = fr1;

        FragmentManager manager = getFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.fragment, fr);
        transaction.commit();

        Bundle bundle = new Bundle();
        bundle.putString("data", String.valueOf(alist));

        fr1.setArguments(bundle);

        startButton.setVisibility(View.GONE);

    }


    public void setData(LinkedList<WidgetClass> list){
        alist = list;
        System.out.println(alist.get(0));

    }

    public LinkedList<WidgetClass> getData(){

        return alist;
    }

    public void startProgress()
    {
        // Run network access on a separate thread;
        new Thread(new Runnable(){

            @Override
            public void run() {
                URL aurl;
                URLConnection yc;
                BufferedReader in = null;
                String inputLine = "";
                WidgetClass widget = null;
                LinkedList<WidgetClass> alist = null;

                int counter = 0;

                Log.e("MyTag","in run");

                try
                {
                    Log.e("MyTag","in try");
                    aurl = new URL(urlSource);
                    yc = aurl.openConnection();
                    in = new BufferedReader(new InputStreamReader(yc.getInputStream()));


                    //
                    // Throw away the first 2 header lines before parsing
                    //
                    //
                    //
                    while ((inputLine = in.readLine()) != null)
                    {
                        if(counter >= 13 || counter == 2) {
                            result += inputLine;
                            Log.e("MyTag", inputLine);

                        }
                        counter++;
                        ;
                    }


                    in.close();
                }
                catch (IOException ae)
                {
                    Log.e("MyTag", "ioexception");
                }





//
//             Now that you have the xml data you can parse it
//
                try {
                    result = result.replaceAll("geo:","");
                    XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                    factory.setNamespaceAware(true);
                    XmlPullParser xpp = factory.newPullParser();
                    xpp.setInput(new StringReader ( result ));
                    int eventType = xpp.getEventType();
                    while (eventType != XmlPullParser.END_DOCUMENT)
                    {
                        if (eventType == XmlPullParser.START_TAG) {
                            if (xpp.getName().equalsIgnoreCase("channel")){
                                alist = new LinkedList<WidgetClass>();
                            }
                            else
                            if (xpp.getName().equalsIgnoreCase("item")) {

                                Log.e("MyTag", "Item Start Tag found");
                                widget = new WidgetClass();
                            } else if (xpp.getName().equalsIgnoreCase("title")) {
                                // Now just get the associated text
                                String temp = xpp.nextText();
                                String locTemp = temp.substring(30,temp.length() - 27);

                                // Do something with text
                                Log.e("MyTag", "Title is " + temp);

                                widget.setMagnitude(temp.substring(25,28));
                                widget.setLocation(locTemp);

                            } else if (xpp.getName().equalsIgnoreCase("description")) {
                                // Now just get the associated text
                                String temp = xpp.nextText();


                                // Do something with text
                                Log.e("MyTag", "Description is " + temp);

                                String tempDepth = temp.substring(temp.length() - 23, temp.length()- 21);
                                tempDepth = tempDepth.trim();

                                widget.setDepth(tempDepth);



                            }
                            else if (xpp.getName().equalsIgnoreCase("pubDate")) {
                                // Now just get the associated text
                                String temp = xpp.nextText();
                                // Do something with text
                                Log.e("MyTag", "Date is " + temp);
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss", Locale.ENGLISH);
                                    LocalDate date = LocalDate.parse(temp, formatter);
                                    widget.setDate(date);
                                }


                            } else if (xpp.getName().equalsIgnoreCase("lat")) {
                                // Now just get the associated text
                                String temp = xpp.nextText();
                                // Do something with text
                                Log.e("MyTag", "Latitude is " + temp);
                                widget.setLatitude(temp);
                            } else if (xpp.getName().equalsIgnoreCase("long")) {
                                // Now just get the associated text
                                String temp = xpp.nextText();
                                // Do something with text
                                Log.e("MyTag", "Longitude is " + temp);
                                widget.setLongitude(temp);
                            }
                        }
                        else
                        if(eventType == XmlPullParser.END_TAG){
                            if (xpp.getName().equalsIgnoreCase("item"))
                            {
                                Log.e("MyTag","item is " + widget.toString());
                                alist.add(widget);
                            }
                            else
                            if (xpp.getName().equalsIgnoreCase("rss"))
                            {
                                int size;
                                size = alist.size();
                                Log.e("MyTag","widgetcollection size is " + size);
                            }
                        }

                        eventType = xpp.next();
                        Log.e("MyTag","Next Event");

                    }


                } catch (XmlPullParserException ae1) {
                    Log.e("MyTag","Parsing error " + ae1.toString());
                } catch (IOException e) {
                    Log.e("MyTag","IO error during parsing");
                }

                System.out.println(alist);
                System.out.println(alist.get(0));




                setData(alist);








//             Now update the TextView to display raw XML data
//             Probably not the best way to update TextView
//             but we are just getting started !
//                rawDataDisplay.post(new Runnable(){
//                    public void run(){
//                        rawDataDisplay.setText(result);
//
//
//                    }
//                });
            }
        }).start();





    } //

    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.

//        public String listToString (LinkedList<WidgetClass> list) {
//            String s = "";
//            Iterator<WidgetClass> iterator = list.iterator();
//            while (iterator.hasNext()) {
//                s = s + iterator.next() + "\n";
//            }
//            return s;
//        }

    }

