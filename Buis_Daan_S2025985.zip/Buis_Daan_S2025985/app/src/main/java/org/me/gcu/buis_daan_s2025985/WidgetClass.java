package org.me.gcu.buis_daan_s2025985;

import java.time.LocalDate;

public class WidgetClass {
    private String title;
    private String location;
    private LocalDate date;
    private String longitude;
    private String latitude;
    private String magnitude;
    private String depth;




    public WidgetClass() {
        title = "";
        location = "";
        date = null;
        longitude = "";
        latitude = "";
        magnitude = "";
        depth = "";
    }
    public WidgetClass(String atitle, String alocation, LocalDate adate, String alongitude, String alatitude, String amagnitude, String adepth) {
        title = atitle;
        location = alocation;
        date = adate;
        longitude = alongitude;
        latitude = alatitude;
        magnitude = amagnitude;
        depth = adepth;
    }

    public String getTitle() {
        return title;
    }

    public String getMagnitude() {
        return magnitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getLocation() {
        return location;
    }

    public String getDepth() {return depth; }

    public void setTitle(String atitle) {
        this.title = atitle;
    }

    public void setLocation(String alocation) {
        this.location = alocation;
    }

    public void setDate(LocalDate adate) {
        this.date = adate;
    }

    public void setLongitude(String alongitude) {
        this.longitude = alongitude;
    }

    public void setLatitude(String alatitude) {
        this.latitude = alatitude;
    }

    public void setMagnitude(String amagnitude) {
        this.magnitude = amagnitude;
    }

    public void setDepth(String adepth) { this.depth = adepth; }

    @Override
    public String toString() {
        return "WidgetClass{" +
                "location='" + location + '\'' +
                ", depth=' " + depth + "\'" +
                ", date='" + date + '\'' +
                ", longitude='" + longitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", magnitude='" + magnitude + '\'' +
                '}';
    }
}

